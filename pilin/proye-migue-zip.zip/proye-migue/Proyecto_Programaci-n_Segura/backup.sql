-- MySQL dump 10.13  Distrib 8.4.0, for Win64 (x86_64)
--
-- Host: localhost    Database: plataformaedu
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add alumno',7,'add_alumno'),(26,'Can change alumno',7,'change_alumno'),(27,'Can delete alumno',7,'delete_alumno'),(28,'Can view alumno',7,'view_alumno'),(29,'Can add intentos',8,'add_intentos'),(30,'Can change intentos',8,'change_intentos'),(31,'Can delete intentos',8,'delete_intentos'),(32,'Can view intentos',8,'view_intentos'),(33,'Can add maestro',9,'add_maestro'),(34,'Can change maestro',9,'change_maestro'),(35,'Can delete maestro',9,'delete_maestro'),(36,'Can view maestro',9,'view_maestro'),(37,'Can add ejercicio',10,'add_ejercicio'),(38,'Can change ejercicio',10,'change_ejercicio'),(39,'Can delete ejercicio',10,'delete_ejercicio'),(40,'Can view ejercicio',10,'view_ejercicio'),(41,'Can add respuesta',11,'add_respuesta'),(42,'Can change respuesta',11,'change_respuesta'),(43,'Can delete respuesta',11,'delete_respuesta'),(44,'Can view respuesta',11,'view_respuesta');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basededatos_alumno`
--

DROP TABLE IF EXISTS `basededatos_alumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basededatos_alumno` (
  `matricula` varchar(10) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellidos` varchar(90) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(256) NOT NULL,
  `chat` bigint NOT NULL,
  PRIMARY KEY (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basededatos_alumno`
--

LOCK TABLES `basededatos_alumno` WRITE;
/*!40000 ALTER TABLE `basededatos_alumno` DISABLE KEYS */;
INSERT INTO `basededatos_alumno` VALUES ('s19016011','Martin','Sanchez Mata','SAMA69','$6$wLn3hfSJdxalxrpH$289690308b4e2544586eb95a2ff4c26f5c443f9046fad9d121b427406a4c2105dc2cfca1c8d6d493da533a199e6c2045ec626e23146aaeb60e8c81c1407b1551',7165229658),('S54684684','Zague','Zague','ZAGUE','$6$wLn3hfSJdxalxrpH$289690308b4e2544586eb95a2ff4c26f5c443f9046fad9d121b427406a4c2105dc2cfca1c8d6d493da533a199e6c2045ec626e23146aaeb60e8c81c1407b1551',7165229658);
/*!40000 ALTER TABLE `basededatos_alumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basededatos_ejercicio`
--

DROP TABLE IF EXISTS `basededatos_ejercicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basededatos_ejercicio` (
  `identificador` varchar(30) NOT NULL,
  `nombreEjercicio` varchar(30) NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `entrada1` varchar(80) NOT NULL,
  `entrada2` varchar(80) NOT NULL,
  `entradaEjemplo` varchar(120) NOT NULL,
  `salidaEjemplo` varchar(120) NOT NULL,
  `fechaInicio` datetime(6) NOT NULL,
  `fechaCierre` datetime(6) NOT NULL,
  `maestro_id` varchar(20) NOT NULL,
  `entrada3` varchar(80) NOT NULL,
  `salida1` varchar(80) NOT NULL,
  `salida2` varchar(80) NOT NULL,
  `salida3` varchar(80) NOT NULL,
  `archivoEntradas` varchar(255) NOT NULL,
  PRIMARY KEY (`identificador`),
  KEY `baseDeDatos_ejercici_maestro_id_71e3a1d9_fk_baseDeDat` (`maestro_id`),
  CONSTRAINT `baseDeDatos_ejercici_maestro_id_71e3a1d9_fk_baseDeDat` FOREIGN KEY (`maestro_id`) REFERENCES `basededatos_maestro` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basededatos_ejercicio`
--

LOCK TABLES `basededatos_ejercicio` WRITE;
/*!40000 ALTER TABLE `basededatos_ejercicio` DISABLE KEYS */;
INSERT INTO `basededatos_ejercicio` VALUES ('uUMaCDv7HRItJlja2ulimTQNM','sexo','asdadas','hola','adios','hola','hola','2024-06-29 19:32:00.000000','2024-07-04 19:32:00.000000','MAHIRO','verde','hola','9','rojo','C:\\Users\\Twili Spark\\Desktop\\Proyecto\\Proyecto_Programaci-n_Segura\\plataforma_respaldo\\casosActividades\\2024-06-29\\uUMaCDv7HRItJlja2ulimTQNM_MAHIRO_2024-06-29.txt');
/*!40000 ALTER TABLE `basededatos_ejercicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basededatos_intentos`
--

DROP TABLE IF EXISTS `basededatos_intentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basededatos_intentos` (
  `ip` char(39) NOT NULL,
  `intentos` bigint unsigned NOT NULL,
  `fechaUltimoIntento` datetime(6) NOT NULL,
  PRIMARY KEY (`ip`),
  CONSTRAINT `basededatos_intentos_chk_1` CHECK ((`intentos` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basededatos_intentos`
--

LOCK TABLES `basededatos_intentos` WRITE;
/*!40000 ALTER TABLE `basededatos_intentos` DISABLE KEYS */;
INSERT INTO `basededatos_intentos` VALUES ('127.0.0.1',0,'2024-06-30 01:33:23.701604');
/*!40000 ALTER TABLE `basededatos_intentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basededatos_maestro`
--

DROP TABLE IF EXISTS `basededatos_maestro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basededatos_maestro` (
  `usuario` varchar(20) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellidos` varchar(90) NOT NULL,
  `contrasena` varchar(256) NOT NULL,
  `chat` bigint NOT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basededatos_maestro`
--

LOCK TABLES `basededatos_maestro` WRITE;
/*!40000 ALTER TABLE `basededatos_maestro` DISABLE KEYS */;
INSERT INTO `basededatos_maestro` VALUES ('MAHIRO','Mahiro','Loona','$6$wLn3hfSJdxalxrpH$289690308b4e2544586eb95a2ff4c26f5c443f9046fad9d121b427406a4c2105dc2cfca1c8d6d493da533a199e6c2045ec626e23146aaeb60e8c81c1407b1551',-1002198582335);
/*!40000 ALTER TABLE `basededatos_maestro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basededatos_respuesta`
--

DROP TABLE IF EXISTS `basededatos_respuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basededatos_respuesta` (
  `identificadorRespuesta` varchar(30) NOT NULL,
  `fechaSubida` datetime(6) NOT NULL,
  `puntos` int NOT NULL,
  `ejercicio_id` varchar(30) NOT NULL,
  `estudiante_id` varchar(10) NOT NULL,
  `archivoSubido` varchar(255) NOT NULL,
  PRIMARY KEY (`identificadorRespuesta`),
  KEY `baseDeDatos_respuest_estudiante_id_0c5416f2_fk_baseDeDat` (`estudiante_id`),
  KEY `baseDeDatos_respuesta_ejercicio_id_54e5172b_fk` (`ejercicio_id`),
  CONSTRAINT `baseDeDatos_respuest_estudiante_id_0c5416f2_fk_baseDeDat` FOREIGN KEY (`estudiante_id`) REFERENCES `basededatos_alumno` (`matricula`),
  CONSTRAINT `baseDeDatos_respuesta_ejercicio_id_54e5172b_fk` FOREIGN KEY (`ejercicio_id`) REFERENCES `basededatos_ejercicio` (`identificador`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basededatos_respuesta`
--

LOCK TABLES `basededatos_respuesta` WRITE;
/*!40000 ALTER TABLE `basededatos_respuesta` DISABLE KEYS */;
INSERT INTO `basededatos_respuesta` VALUES ('WTghrxb5cM4neB2HTwqiiH20iA','2024-06-29 19:48:41.501183',1,'uUMaCDv7HRItJlja2ulimTQNM','s19016011','C:\\Users\\Twili Spark\\Desktop\\Proyecto\\Proyecto_Programaci-n_Segura\\plataforma_respaldo\\respuestasEjercicios\\uUMaCDv7HRItJlja2ulimTQNM\\WTghrxb5cM4neB2HTwqiiH20iA_uUMaCDv7HRItJlja2ulimTQNM_SAMA69.py');
/*!40000 ALTER TABLE `basededatos_respuesta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(7,'baseDeDatos','alumno'),(10,'baseDeDatos','ejercicio'),(8,'baseDeDatos','intentos'),(9,'baseDeDatos','maestro'),(11,'baseDeDatos','respuesta'),(5,'contenttypes','contenttype'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-06-15 23:18:57.851368'),(2,'auth','0001_initial','2024-06-15 23:18:59.054192'),(3,'admin','0001_initial','2024-06-15 23:18:59.414126'),(4,'admin','0002_logentry_remove_auto_add','2024-06-15 23:18:59.429753'),(5,'admin','0003_logentry_add_action_flag_choices','2024-06-15 23:18:59.467069'),(6,'contenttypes','0002_remove_content_type_name','2024-06-15 23:18:59.724560'),(7,'auth','0002_alter_permission_name_max_length','2024-06-15 23:18:59.910889'),(8,'auth','0003_alter_user_email_max_length','2024-06-15 23:19:00.018194'),(9,'auth','0004_alter_user_username_opts','2024-06-15 23:19:00.051618'),(10,'auth','0005_alter_user_last_login_null','2024-06-15 23:19:00.306014'),(11,'auth','0006_require_contenttypes_0002','2024-06-15 23:19:00.306014'),(12,'auth','0007_alter_validators_add_error_messages','2024-06-15 23:19:00.333578'),(13,'auth','0008_alter_user_username_max_length','2024-06-15 23:19:00.497234'),(14,'auth','0009_alter_user_last_name_max_length','2024-06-15 23:19:00.679882'),(15,'auth','0010_alter_group_name_max_length','2024-06-15 23:19:00.754339'),(16,'auth','0011_update_proxy_permissions','2024-06-15 23:19:00.798091'),(17,'auth','0012_alter_user_first_name_max_length','2024-06-15 23:19:00.979970'),(18,'baseDeDatos','0001_initial','2024-06-15 23:19:01.643737'),(19,'baseDeDatos','0002_alter_ejercicio_identificador_and_more','2024-06-15 23:19:01.940723'),(20,'baseDeDatos','0003_alter_ejercicio_identificador_and_more','2024-06-15 23:19:02.277525'),(21,'sessions','0001_initial','2024-06-15 23:19:02.391485'),(22,'baseDeDatos','0004_rename_entrada_ejercicio_entrada1_and_more','2024-06-24 05:01:05.374436'),(23,'baseDeDatos','0005_alter_ejercicio_entrada1_alter_ejercicio_entrada2_and_more','2024-06-24 05:02:03.802870'),(24,'baseDeDatos','0006_ejercicio_archivoentradas','2024-06-24 20:36:08.103529'),(25,'baseDeDatos','0007_respuesta_archivosubido','2024-06-24 23:31:08.137001'),(26,'baseDeDatos','0008_remove_respuesta_codigo_alter_respuesta_fechasubida','2024-06-24 23:54:43.175349'),(27,'baseDeDatos','0009_alter_ejercicio_archivoentradas_and_more','2024-06-27 12:03:37.829459'),(28,'baseDeDatos','0010_alter_ejercicio_archivoentradas_and_more','2024-06-27 12:29:18.576106');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('1gn83nsndapju5r01s02585wi8wq9le7','eyJsb2d1ZW8iOnsib3JpZ2VuIjoiTWFlc3RybyIsInVzdWFyaW8iOiJNQUhJUk8iLCJ0b2tlbiI6ZmFsc2V9LCJ0aWVtcG9EVmlkYSI6IjIwMjQtMDYtMTggMDI6MzY6MjAifQ:1sJUKC:TaOVsReMFjkWkrxazBAmxMKHYQE7FNhb9PYG4vxCInw','2024-06-18 08:46:20.989464'),('2bafo918novtnk7jd7cjppkiz3rsdjrt','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrqGFgoGxlYmRlYGRkq1AP3OH68:1sJVM1:rM9zl9MPjJfA8cdbEnqNOHZ00gJG0-b-iZYh7SPXrog','2024-06-18 09:52:17.600184'),('2du1m21g25qxj3eeprutdjuw9gbxvn3b','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGZgoGplbG5lamFkBdqVmpRcmZyZn58ZkpQEVe4S4FHpW5eSae5SF-jqY5OcFlZekBpZW-SrUABo8tfw:1sMR54:gjlMhPnzQncDcsiLDjpuevkS_EMQGCdST8_8Ohsbx9w','2024-06-26 11:54:54.560343'),('38tbm5klpd1a66mkw1i10cmkpk22yzdg','.eJxVjMEKwjAQBX9F9mwhqW2NuQkeLCiCB_FWQruGtU1X0kbB0n83PXqdN_Mm6NgGZNATsCeLPWg4GxxGz7CGMATjiRe2P5bXS0Qjt3_SHBGhe_HhRo2JQyrSLBFFkm5XQuks15s8ZvhEX1NNXFETJbV7F76VCj_2bh_fPGvwVCrXRtN0wfVcOTN6qkO3XA5yJ2QhpIT5B4dkN0E:1sMqPX:mqGzafw8Xx2QM7euhXX_HCiDQTIsDvYINa8Ja3awziI','2024-06-27 14:57:43.663138'),('4ae1v7pb1hi66a0bv8wg9oczjbetwx23','.eJxVjMEKgkAURX8l3jphZjAdZxe0SCiCFtFOBn3JS8cXo1OQ-O-Ny7bnnnNn6LkNyGBmYE8tDmDgbHGcPMMWwhisJ17Z_lheLxFN3P1JS0SE7sWHGzU2DkqoNBFZovKN0EblRhQxwyf6mmriipoo6eKd-U5q_LT39vHdpQ2eSu26aNo-uIErZydPdejXy1EWQmZCSlh-h6s3Qg:1sMq6H:RcXnY7s0OkKgvs91wnS44qVRfHN4hPk5OyeG8pdTxeE','2024-06-27 14:37:49.091732'),('4yiqdf446wu0j1mnvwtz1yflw82ir2ll','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGxgpGRlYGBlbGRkq1AP2OH6k:1sLat4:yH8m_DylA7CgsjrFhbXLEYGnrRP2uahpfvB9YISW3fo','2024-06-24 04:11:02.612761'),('5jwwflkhk3qg8gmazhy16l6nvbsczema','.eJxNi8EKwjAQBX9F9mwhxLZgboEeVKgILXqU0oawmmRLNC2l9N_do_BO82ZWcGSTIVArUERrAijQLvlAsIf0SV1EPqHRtS6PjL70_nc2Jmj8SNUdh465FDLPRJnJYielErwDV-ZlYo890hMHli6PajwtPuTnub3qwrlmmuwtLTVsPwLKLWs:1sMJrO:m1RhFQWNu4WSG-nDD8FsoZKsSGD160pwkZyS4iufkwI','2024-06-26 04:12:18.564292'),('5q6unhke5ylwb5ho5d11zt13enr6yrh6','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpG5goGplamZlamJkBtiTmluXn58bmJJUWZyaU5IIXFhpYGhmYGhoZKtQB8_Sle:1sMnoI:V4oPKi3_mu6lV8nlZFlvEs0JplGzWgzcyGeOFMmNo_M','2024-06-27 12:11:06.163807'),('6mu7yyn966dwrchbxh4cyjjmxuom8n0u','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGZgoGxlbGZlYGIF2pWalFyZnJmfnxmSlARV7hLgUelbl5Jp7lIX6Opjk5wWVl6QGllb5KtQAFOS14:1sMP4h:4URC0AhOZm2cLa6jJ7ESwcYW67rxjpR4pr_VvEpy34U','2024-06-26 09:46:23.153610'),('7lsrx75rexfti9oz96imh1paoqxm9aar','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpG5goGBlaGRlZGlkBtqVmpRcmZyZn58ZkpQEVe4S4FHpW5eSae5SF-jqY5OcFlZekBpZW-SrUAjJ8ufw:1sMiN7:S1mJkYL5jIqm8pr8BiIDrW_wY_5z5YEVykpS4a5pBFU','2024-06-27 06:22:41.129552'),('7o852hhs12ubcn8v3f3g28a7f5fekjg3','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGJgpGhlZGplYGpkq1AP26H7A:1sLwoh:xTSk7f10v4WnjlnvwA-P-Mry3iB-NERGB_yI0QaXq_M','2024-06-25 03:35:59.585093'),('7tmni1nyh5nivw5lrjcy94vupqnxjxdz','.eJxNy8EKwjAQRdFfkVlbqGNaMLtAFypUhIoupbQhTE0yJZpKKf13s3R73n0LWDZRM8gFOJDRHiQoG51n2EJ8xzZQGqFRtSoPiT78-m_WJKTdyNWd-jY55iiyvMyw2CDKHcq9SC896NBRR_ykPkXnRzUeZ-fF6Xu7qMLaZprMNc41rD8Dty1w:1sMK1Y:e1jNQjE3vlx0Dqu-2XAXq5CmUkyY5UZFr5Exe1eoVCY','2024-06-26 04:22:48.167945'),('91a0pxj6fjludozk2hmfxkl6do354r5s','.eJxVjF0LgjAYRv9K7Dph87N2J3ihgRUVdSlDh7y1-cp0hoj_vXnZ7XnOeRaisLUSCV8IGmhlRzgphRxGg2RP7GCFAdxYmhe3i0Mjfv6k1SGQusfsCY1wg0_90KOx5yc7GvAo4cHBZfItTQ01YAWNk06vrM9n3YXF93FOI6Xu09Re7Vw6VSirO6y0GA3UVm2fAztSFlPGyPoD2N04LA:1sMm6S:El8yt2ZS-3PVTDZKKM5UGmi4Mt1YQJYL1MJTn9pPyC4','2024-06-27 10:21:44.336066'),('9uawiqoy1es48qgnjheqtrkz7a6phrto','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGZgpGxlYmllYGZkBtqVmpRcmZyZn58ZkpQEVe4S4FHpW5eSae5SF-jqY5OcFlZekBpZW-SrUAjnMuiA:1sMi0W:8ghakxCelX1-v_j157PldZzV7fSFAZ2VXaw2QXcjHkk','2024-06-27 05:59:20.458688'),('9xib4ncc5krn1fd7gyc5k5ygg98uwczf','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrqGFgoGxlam5lYGZkBtqVmpRcmZyZn58ZkpQEVKtQBwKCWA:1sJVbM:PWNRgoWmEJkXBcOWRcgPjcaN3gEmp9lRQBQWtlVHEeg','2024-06-18 10:08:08.801415'),('a228kdedm8h5hx58binxgg3ljz0w4wgx','.eJxNy8sKwjAQheFXkVlbCIlGm11ALF0UBKW6k5qEMvYyJRoQS9_dWbr9zn9m6KlNgcDMQBHbMIIB26dhJFhDeqUmIo9wtpXVOdObuv9mYcEwTHSo0TfsUshNJnQm9yuhjMqNEPwKzxAdOqQ7eo6u_lMW_jR9lY7-Ut-2ylbxsSuPDpYfLfctAw:1sN84V:BTxdWosx4L5AzGOS6btxBQPF4aMdrWmsYFzV3Mrc3G4','2024-06-28 09:49:11.637507'),('ai6qhni865yssgreiy4ghpdb2kqj621c','.eJxNy8EKwjAQRdFfkVlbKGMTMLtAFypUhIoupbQhjCaZEk2llP67Wbo9774FHNtkGNQCHMmaAAq0Sz4wbCG9Uxcpj9DqRst9pg-__ps1Cxk_cn2jocuOJVZFKQsUG0SFQu1kfpmniT31xA8acnS61-Nh9qE6fq9nLZxrp8le0tzA-gME2C12:1sMKED:bUs27UBsiXaq8A1mkkpaJN48l-_rFAnXvixAmhy3LQA','2024-06-26 04:35:53.186828'),('bjl623qf1fxf0iwhjxvsskqc0upl6g00','.eJxNy7EOgjAUheFXMXe2CdZKtVsTHJSYaBpwNARuyFXgmpZOhHe3o-t3_rPAwH1EBrMAe-pxAgN2iOPEsIUYYuMpjeDszeanRDN__ps1CeH45aKmrkkuM6lElgupNjtt9tIcdHrhG31LLfGLuhQ9qnvpxewuymsu8RqaUOOTK3c-wvoDWsAtlw:1sLtBT:GjGNNq2Vkxu7AFTUf-n7f6rnTPKdturt37JRSI2we08','2024-06-24 23:43:15.486775'),('bv5me7gfqfhe5f8zua1j5rdnwes28e6u','.eJxNy8EKwjAQRdFfkVlbCENTMLtAFypUhIoupbQhjE0yJZpKKf13s3R73n0rOLbJMKgVOJI1ARRol3xg2EN6py5SHqHVja4OmT48_jdbFjJ-4vpOQ5cdBZaFqAqUO0QlS4Uiv8zLxJ564icNOTo_6um4-FCevreLls6182yvaWlg-wED-i1x:1sMKfx:aXqWIlvTgP3yke1ID-4coeOO3aeb5IlsUeJ0bYyxZo0','2024-06-26 05:04:33.788975'),('cje9cvhuzd8o0seuzr7uu69ujvz4asae','.eJxVjMEKwjAQBX9F9mwhqbWmuQkeLCiCB_FWQruGtU1X0kbB0n83PXqdN_Mm6NgGZNATsCeLPWg4GxxGz7CGMATjiRe2P5bXS0Qjt3_SHBGhe_HhRo2JQyrSLBF5ku5WotBio6WKGT7R11QTV9RESRXv3LdS4cfe7eO7zRo8lcq10TRdcD1Xzoye6tAtl4MshMyFlDD_AIYiNz0:1sMqto:shdXZaVuOligoq4rpACmzGLk9j1AhanCn0FbSpXCz2w','2024-06-27 15:29:00.486249'),('dekbmikro5yvml4plvs0qkldmqd233m4','.eJxNy8EKwjAQRdFfkVlbCDFGzC7QhQoVoaJLKW0Io0mmVFMppf_uLN2ed98MgXx2BGYGGtC7BAZsyDERrCG_czMgj1Dbyuo904de_83Cgi72VN6wa9ilkKoQupB6JTZG7YzS_HJPN7TYIj2w4-h0L_vDFJM6fq9nuw2hHkd_yVMFyw8Fzi17:1sMPFu:6kn81GM_7ZnKzmGS_7Zza196q1UxfjqfDXIKU5rA-4g','2024-06-26 09:57:58.454648'),('dxk076r3j2ge2nsd1yxxatsgwfx5v5xk','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGxgpGBlamxlYGFkq1AP23H7I:1sLZpl:G3s5mdhZotekkst5u0fHMA9H3IeHgeUO0WMGTztncKE','2024-06-24 03:03:33.915890'),('e4i8aoo9x4vf84b09iz6iinb13no2h41','eyJsb2d1ZW8iOnsib3JpZ2VuIjoiTWFlc3RybyIsInVzdWFyaW8iOiJNQUhJUk8iLCJ0b2tlbiI6ZmFsc2V9LCJ0aWVtcG9EVmlkYSI6IjIwMjQtMDYtMTggMDE6NDk6MTEifQ:1sJTaZ:5pnKUuMJTDd8ShT484BhqBgoWmlSQDsZxbpGa44Iku4','2024-06-18 07:59:11.918699'),('eohhzxocztiibtqxq2gt37r8a8261lfh','.eJxNy7EKwjAUheFXkTtbSEJN02wFF0EnQdykNNdwTdMr0ShY-u7GzfU7_5lhZJ-Rwc7AiTxOYKEbc5wY1pAfuU9URjh2h063hZ4c_pulCGG88_ZEri-uhKoroSvVrERjpbLy98IbpoEG4gu5Epn2pVOQBt_-7K-fTe1wvzMxwPIF0WAsjg:1sMovN:eXXfeQlUvbRzMFN-B5Tjr655-Geix8UEW5VURtnAc6o','2024-06-27 13:22:29.294867'),('eu98n8gf6gx29le3fo890fwst4s0fqu7','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGlgqGZlYmRlZGFkBtqVmpRcmZyZn58ZkpQEWJeU6hZVl5qcYmLqlFHhGR2ZkBhoXmZb5pVY5KtQDtMS75:1sNguJ:2v0pKPf02gS042ArP_ivItLK9Ugi9le3Ntv_xYN49Ow','2024-06-29 23:00:59.677934'),('f975qmwofet4bqf5m324x5p7h1a7t2z7','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpG5goGBlZAZGIO1JaalVqUnJmcmR-fmQJU5BXuUuBRmZtn4lke4udompMTXFaWHlBa6atUCwCMDS58:1sMiBn:CR_sKpNI5npvSIbdqcerQpa3Kc7sfftjN5KEnNmr8l0','2024-06-27 06:10:59.338255'),('gkxpx9hrpi5onjbgfhobubfg09dq60mg','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGxgoGRlZGRlaGBkq1AP2GH6c:1sLIUZ:u2oygHkwHesE9CGwIGVgvn-5ZDI9m-D-NTaEwRBpNCk','2024-06-23 08:32:31.502086'),('j9w45bxxc13xyi4nbqjyvuzbdpbb7b03','.eJxNy7EKwjAUheFXkTtbiCGNabaAi6CTIG5Smmu4pumVaBQsfXczun7nPzOMHAoy2Bk4U8AJLLixpIlhDeVZ-kx1hJM7Ot1VenH8b5YqhOnBuzP5vroUUjVCN3K7Etq2xgpVX3jHPNBAfCVfI9O9dY4bg59wCbdvqzwe9iZFWH7SAiyR:1sMohb:XyJ8t3hAVV7gWIFLJdn3qx92NBfutk23ndQYugIFFp4','2024-06-27 13:08:15.811040'),('kg8ra57r1xdg8j9hac0r86hglf2b2yu6','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGxgoGhlYmZlYmRkBtqVmpRcmZyZn58ZkpQEVKtQBvTiV4:1sLHxW:UHnNJmuXQMv2Wwnzkjj2FjW2fRQWScqgzCnXbYgzMbY','2024-06-23 07:58:22.722158'),('kogmtpux4axg4volxvdgl10q0nh915s2','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGxgoGRlYmJlYm5kq1AP3BH7U:1sLItX:99fu6BFQovwIHU2tSnxLmEi5b-A14yCXAUfJBqTGjPI','2024-06-23 08:58:19.821067'),('kxm2viy87ynxlcle5vfsmwwamz1xrp5s','.eJxVjMEKgkAURX8l3jphnMxwdoELDayoqKUMOsirGZ-MjiHivzcu2557zp1BU-MUgZiBLDaqBQGFVP1gCbbgeict0sqOWX67eDTQ509aPEJlOkqfWEs_cMajgMUBP2zYTrBY8MRn6q1shRVSibWXTq-0yybTRvn3cT7utb6PY3N1U-FVqZ1pqTRysFg5vX72YcLCmIUhLD_W9zgm:1sMl8P:EW5bltDzBiI_3LDjw_wSXffQrSxJY3proDXT-WNCQzo','2024-06-27 09:19:41.694538'),('l0qinskzr3prk268r6b8cbus6293gyni','.eJxNy7EKwjAUheFXkTtbCCEJmC3QQYWKUNFRShvCtUluiaZSSt_djK7f-c8Knly2BHoFSuhsBA3G5xAJ9pDfuUtYRmhNY9Sh0IfG_2YrgjZMVN9x6IpzxkXFVMXljnMtmJaqvOzLph57pCcOJTo_6um4hChO39vFSO_beXbXvDSw_QAEpS11:1sMKTA:_2Ebsz-TrTRQehu4bJrzsh6RLP-yeUR0t2Rin_ulFNY','2024-06-26 04:51:20.417378'),('l6i9g7757wlkgty9zuvfj9h70vht4of5','.eJxNy8EKwjAQRdFfkVlbCKGJmF2gCxUqQkWXUtpQRpNMiaZSSv_dWbo9774FPA3ZEZgFKOHgIhiwPodIsIX8zm1CHqGxtdV7pg-9_puVBV0Yqbph37JLIctC6ELqjVBGKqN2_HJPlzrskB7Yc3S6V-NhDrE8fq9nq7xvpmm45LmG9QcFzS17:1sMQmx:G61YB3OO5dEJLxTkVklv3DisQkKlLJRYh6x3tHTcnpc','2024-06-26 11:36:11.274708'),('m725q2nmb9h8ovtt58ug0xt58wu4p9yh','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGZgqGZlaGxlamlkq1AKKcHq8:1sMatz:lpJxVRsm6gRtYgt8crl-fz1hBYD2fPvQy-ZS9vHBX94','2024-06-26 22:24:07.784380'),('m8ev17lq81fu7mpbchtes44wgmgtst0c','.eJxNy7EOgjAUheFXMXe2CdYK2I0EByUmmgYcTQM35CpwTUsnwrtbN9fv_GeBgfuADHoBdtTjBBqKIYwTwxaCD9ZRHMEU1yI9Rpr5_d-sUQjHD5cNdTa6TKQSSSqk2uwyfcj1_vfCF7qWWuIndTG617fKidmclcu4wou3vsEH1-aUw_oFXFgtnw:1sLtaF:XRgLoCqJt39_Fbz6BpO1mzDYtrREi5Ja9OSgMCnqjIM','2024-06-25 00:08:51.227984'),('nz59jr39htxgbslni1ypm6yi1vhff4m9','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGJgoGRlbG5lZG5kq1AKJqHqk:1sLfCx:fF7Pu2evLDpIqSBbRHde-98GKEGXMYsSvbV9Ru5jXp8','2024-06-24 08:47:51.310134'),('omq2sxqclvfkr8b6ylhekdfat8llq9ao','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrqGFgoGxlYGplaGhkBtqVmpRcmZyZn58ZkpQEVKtQBvKCV1:1sJUxu:vwBfaLd982c-CU9cfvcMMSBusjGEH2CDAE5_wNmR_BM','2024-06-18 09:27:22.494611'),('p01uj9mm3vsoiuqnw28ug2cxkhzyjh0n','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGJgpGBlam5lYmJkq1AP3fH7c:1sLwd0:HpY6g2R7F3u23dPhvL5XPphH_4MwYeRi2xEAUmXhrno','2024-06-25 03:23:54.150818'),('qayy111zh18noyltri55nlddo1w0nyph','.eJxNy7EOgjAUheFXMXe2SW0KaLcmOCgx0TTgaAjckKvANS2dCO9uR9fv_GeFkYeIDGYF9jTgDAbsGKeZYQ8xxNZTGsHZm81PiRb-_DdbEsLpy2VDfZtcSaWFzIXSu0NhdGYymV74Rt9RR_yiPkWP-l55sbiL9gVXeA1taPDJtTsfYfsBWj0tlA:1sLtNs:346WKmxX4ZTYDJ8kZbgswDmTI6cy-qr3S7ocFCdqFWc','2024-06-24 23:56:04.586050'),('qj89miy49ypzrv68b7l891irgbm96zpq','.eJxVjFELgjAURv9K3OeEbZjR3oQeNLCioh5l6JBbm1emM0T8783HXs93zjeDocZrAjkDOWx0CxIKpfvBEWzB9145pJWlWX67BDTQ509aAkJtOzo-sVZhEEzEEUsisd-wWAoheRIy_dauwgqpxDpIp9exyybbxvn3cU53xtzHsbn6qQiqMt62VFo1OKy8WT97fmA8YZzD8gPVdzgh:1sMmH3:1g8Z9ZJfSWYpCclXNSjsNexVzsBJ5p2yoQPE9rUyyBk','2024-06-27 10:32:41.144761'),('qmum8gtmat5ovc5r0tcyddonud5p9qfc','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGJgqGJlbGllZGhkq1AP3mH7U:1sLqTe:pkrGjX6YUu-LOR_VCjpsoGLYQYqU3x-wvXFFHb-nFmc','2024-06-24 20:49:50.283825'),('r8boq6sst065ocijhod2freacitojvko','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGJgqGplbG5lamZkq1AP3-H7w:1sLrOF:3z7Aqh5o4PmTjFf4-IU1mbp7L38AFFFtJeieM8nrBhg','2024-06-24 21:48:19.101777'),('rcjqurm19no0u3bjeyss92ash9gsv8of','.eJxNy0ELgkAQhuG_EnNO0EGl9rbgoQIjMOoYootM7e7I1hoi_vfm2PX53m8By0M0DGoBDjQYDwq0jc4zbCG-YxtIRmh0rcu90Idf_80qQsaNXN2ob8UxxTxJywSLDWYKdypDeZmnCR11xA_qJTrdq_EwO58fv9ezLqxtpmm4xLmG9QcEIS1y:1sMJKc:Zg3tpEfrBJwgl3YcfDcHxp398EZQWyYW9TDrQE9Qgzg','2024-06-26 03:38:26.137783'),('rqfwesosh76lr5knjaqqkyvj4r20vr4y','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGZgoGxlYGBlYGIF2pWalFyZnJmfnxmSlARV7hLgUelbl5Jp7lIX6Opjk5wWVl6QGllb5KtQADfS1v:1sMOXl:baZbAc6ck8D2V7syib9JC3Y7ua1a2L92X7TN4mDXqK0','2024-06-26 09:12:21.641074'),('s4kmmla997go3dh3i0ffem7s9j2l0lsq','.eJxNy7EKwjAUheFXkTtbSNMa02wBF0EnQdykNNdwTdMr0ShY-u5mdP3Of2YY2WdkMDNwIo8TGLBjjhPDGvIz94nKCCd7tKor9OLw3yxFCOODd2dyfXEpZFsJVcntSijT1EY25YV3TAMNxFdyJdLdW6VQa_z4i799N63Dw17HAMsP0H8siQ:1sMoWe:9ej7OHH8c1NAmEa1uJwOb_6RNhOcG7S-lFi5RRJyraY','2024-06-27 12:56:56.128952'),('sqgyt273ownyyunpicvh5j28e8k3kavy','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpG5goGZlaGplZGFkq1AP4BH7o:1sMo2L:NEfYj9w-TZqcZ7ejGWHsgoyayaFfM2tk3Xdeo-jLrak','2024-06-27 12:25:37.402438'),('tulzw6ymz3xrptk1sx8z1lkri8myqmtt','.eJxNy7EKwjAUheFXkTtbaEMSMFuggwoVoaKjlDaEW5PcEk2llL67GV2_858VHNlkCNQKFNGaAAq0Sz4Q7CG9Uxcxj9DqRstDpg-9_pstCxo_UX3HocvOSsaLUhZM7FiluFSVyC8zmthjj_TEIUfnRz0dFx_46Xu7aOFcO8_2mpYGth8ErS11:1sMJc0:TARi8Zla4FzSlOIT4IDTyitFRqnvBkDW3S84PUNzeUA','2024-06-26 03:56:24.963407'),('uaacvyriq4d3dh3qcoyeik5gu3yszsod','.eJxNy8EKwjAQRdFfkVlbCLEGzC7QhQoVoaJLKW0IU5NMiaZSSv_dWbo9774FPLlsCfQClNDZCBqMzyESbCG_c5uQR2hMbdSB6UOv_2ZlQRtGqu7Yt-xSyLIQqpBqI3ZaCi0Vv-xgU4cd0hN7js6PajzOIZan7-1i9t430-Suea5h_QEDtS1w:1sMOsZ:Vn7z6QZEdWIqN5hU1VZgAyGt7E7QJJkCE19UydHAFYM','2024-06-26 09:33:51.726528'),('uj6p6ibbav5v09y0y9v8fffffpx38r7o','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrpGlgqG5lZG5lbGpkq1AP46H78:1sNhUN:pxZl375ZZQu8xllriQ7JIyfL0cCmmX0_YXNI_AhzsvE','2024-06-29 23:38:15.779085'),('vqg3y88vdf5f1kpf3x41hyecw4gozay9','.eJxVjMEKgkAURX8l3jphHM1odoELDayoqKUMOsirGZ-MjiHivzcu2557zp1BU-MUgZiBLDaqBQGFVP1gCbbgeict0sqOWX67eDTQ509aPEJlOkqfWEs_cMbjgCUB329YJDgXEfOZeitbYYVUYu2l0yvtssm0cf59nI87re_j2FzdVHhVamdaKo0cLFZOr599eGBhwsIQlh_T8jgc:1sMlZB:V2EktJZTvhWYTL-DUUrrg9zEE4MPPP4I8-sTKnfwyv4','2024-06-27 09:47:21.550090'),('w74uc4uze6kx18ws56pjmz8lvupc1ld6','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGJgqGllbGplYmlkq1AKK1HrM:1sLv6J:vWokNFw73c-22XQcMSXkjcAcp_Tc3gRsi2SSzIhzkeI','2024-06-25 01:46:03.496725'),('whc963m26ezpk06h2lrno5z7fi5zn7ch','.eJxVjMsOgjAUBX_F3LUkbSEV2PmMRsTEBLemQkOqLVdaupHw75al2zkzZwSNrZcI-QhoVSs7yOEipBsswhK888IqnNn6eLpdAxrw_SdNASlpPri7q0aEgRGWRIRHbLWgcc7inGYhky9pa1UrfKgmSMlTH769K88-7dOKF1W5JcXG8L1Lgiy0Nx0-jBisqr2eXx3NCOWEUph-IC03vg:1sMulk:OrNVw0q9fS9t-aN3mbMhk4FSFPzXajYAd5ohTtROGmM','2024-06-27 19:36:56.868201'),('xll6ivl46qse9zftmqvawqpniyxaz2wo','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslLyTUwtLinKV9JRKi0uTSzKzAeJOXp4BvkDhUrys1EU1QKFMlNzC_JdwjJTEoESRgZGJroGZrqGpgpGRlYGllam5kBtqVmpRcmZyZn58ZkpQEVKtQBwISWB:1sIhPZ:l6eiTPwO3nRyMiCa1ioGP3FMnZNEt3wAqfGFoaqj58s','2024-06-16 04:32:37.755498'),('yhzrt5q2xrvquwwtvz7xrf41b6viqyr6','eyJsb2d1ZW8iOnsib3JpZ2VuIjoiTWFlc3RybyIsInVzdWFyaW8iOiJNQUhJUk8iLCJ0b2tlbiI6Inl5ZWhOaTlhOVhXdEx2TTMifSwidGllbXBvRFZpZGEiOiIyMDI0LTA2LTI4IDAzOjM3OjA2In0:1sN82U:qB80gzQkfSjPwCA57BCe76GNkkHLHYuGPDCcgqZ6wxY','2024-06-28 09:47:06.187814'),('yzxmzn0hxp00ybfdh26h1dar65ujhyar','.eJyrVsrJTy9NzVeyqlbKL8pMT81TslJyzCnNzctX0lEqLS5NLMoESioFO_o6mlkChUrys5HV1AJFMlNzC_JdwjJTEoHiRgZGJroGZrpGpgpGxlaG5lYmxkBdqVmpRcmZyZn58ZkpQEVe4S4FHpW5eSae5SF-jqY5OcFlZekBpZW-SrUABOEtdg:1sML2i:FXlivHbJuXybjLOfXj1lUCY8CYxwafZs_3CejJ17QPo','2024-06-26 05:28:04.553494');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-01  0:04:53
