from django.db import models

# Create your models here.
class Intentos(models.Model):
    ip= models.GenericIPAddressField(primary_key=True)
    intentos=models.PositiveBigIntegerField()
    fechaUltimoIntento=models.DateTimeField()

#?
class Alumno(models.Model):
    matricula=models.CharField(max_length=10, primary_key=True, unique=True, null=False)
    nombre=models.CharField(max_length=30, default='')
    apellidos=models.CharField(max_length=90, default='')
    usuario=models.CharField(max_length=20, default='')
    contrasena=models.CharField(max_length=256, default='')
    chat=models.BigIntegerField()

class Maestro(models.Model):
    usuario=models.CharField(max_length=20, primary_key=True, unique=True, null=False)
    nombre=models.CharField(max_length=30, default='')
    apellidos=models.CharField(max_length=90, default='')
    contrasena=models.CharField(max_length=256, default='')
    chat=models.BigIntegerField()

class Ejercicio(models.Model):
    identificador = models.CharField(max_length=30, primary_key=True, unique=True, null=False)
    maestro = models.ForeignKey(Maestro, to_field='usuario', on_delete=models.CASCADE)
    nombreEjercicio = models.CharField(max_length=30, default='')
    descripcion = models.CharField(max_length=500, default='')

    # Modificar para permitir múltiples conjuntos de datos
    entrada1 = models.CharField(max_length=80, default='')
    salida1 = models.CharField(max_length=80, default='')
    entrada2 = models.CharField(max_length=80, default='')
    salida2 = models.CharField(max_length=80, default='')
    entrada3 = models.CharField(max_length=80, default='')
    salida3 = models.CharField(max_length=80, default='')

    entradaEjemplo = models.CharField(max_length=120, default='')
    salidaEjemplo = models.CharField(max_length=120, default='')
    fechaInicio = models.DateTimeField()
    fechaCierre = models.DateTimeField()
    archivoEntradas = models.CharField(max_length=255, default='')

class Respuesta(models.Model):
    identificadorRespuesta=models.CharField(max_length=30, primary_key=True, unique=True, null=False)
    ejercicio=models.ForeignKey(Ejercicio, to_field='identificador', on_delete=models.CASCADE)
    estudiante=models.ForeignKey(Alumno, to_field='matricula', on_delete=models.CASCADE)
    #codigo=models.CharField(max_length=90, default='')
    fechaSubida=models.DateTimeField()
    puntos=models.IntegerField(default=0)
    archivoSubido = models.CharField(max_length=255, default='')  # Ruta relativa del archivo subido