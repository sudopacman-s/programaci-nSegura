import pyAesCrypt

# Tamaño del búfer (debe ser igual al usado en el cifrado)
bufferSize = 64 * 1024

# Solicitar la contraseña al usuario
print("Escribe la contraseña:")
password = input()

# Archivo encriptado
encrypted_file = "DNIEX.env.aes"
# Archivo desencriptado
decrypted_file = "DNIEX.env"

# Desencriptar el archivo
try:
    pyAesCrypt.decryptFile(encrypted_file, decrypted_file, password, bufferSize)
    print(f"Archivo desencriptado correctamente: {decrypted_file}")
except Exception as e:
    print(f"Error al desencriptar el archivo: {e}")
