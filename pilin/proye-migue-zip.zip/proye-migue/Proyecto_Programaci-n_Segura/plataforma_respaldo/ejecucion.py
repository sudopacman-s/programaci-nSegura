import os
import pyAesCrypt
from getpass import getpass

# Variable para indicar si se ha activado correctamente el archivo DNIEX.env
activado = False

def descifrar_archivo_env(archivo_encriptado, archivo_descifrado, contraseña):
    try:
        pyAesCrypt.decryptFile(archivo_encriptado, archivo_descifrado, contraseña)
        return True
    except Exception as e:
        print(f"Error al descifrar el archivo: {e}")
        return False

def cargar_archivo_env(ruta_archivo):
    global activado
    try:
        with open(ruta_archivo, 'r') as archivo:
            for linea in archivo:
                activado = True
                linea = linea.strip()
                partes = linea.split('=')
                if len(partes) == 2:
                    os.environ[partes[0]] = partes[1]
                    print(f"Variable de entorno establecida: {partes[0]}")
    except FileNotFoundError:
        print(f"Archivo no encontrado: {ruta_archivo}")
        activado = False

def main():
    print("Escribe la contraseña:")
    contraseña = getpass()  # Captura segura de la contraseña

    archivo_encriptado = "DNIEX.env.aes"
    archivo_descifrado = "DNIEX.env"

    if descifrar_archivo_env(archivo_encriptado, archivo_descifrado, contraseña):
        cargar_archivo_env(archivo_descifrado)
    else:
        print("No se pudo descifrar el archivo.")
        exit(1)

    if not activado:
        print("No se pasó correctamente la contraseña")
        exit(1)

    print("Iniciando el servidor Django...")
    os.system("python manage.py runserver 0.0.0.0")

if __name__ == "__main__":
    main()
