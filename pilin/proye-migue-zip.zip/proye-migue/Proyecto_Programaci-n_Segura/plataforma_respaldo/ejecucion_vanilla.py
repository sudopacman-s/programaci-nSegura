import os  # Importa el módulo os para interactuar con el sistema operativo.
import pyAesCrypt  # Importa pyAesCrypt para operaciones de cifrado y descifrado AES.
from io import BytesIO  # Importa BytesIO para trabajar con datos en memoria como archivos binarios.
from getpass import getpass  # Importa getpass para capturar la contraseña de forma segura.

def descifrarArchivoBuffer(archivoEncriptado, contraseña):
    """
    Descifra un archivo encriptado y lo carga en un buffer de BytesIO.

    Parameters:
    archivoEncriptado (str): Ruta al archivo encriptado.
    contraseña (str): Contraseña para descifrar el archivo.

    Returns:
    BytesIO: Buffer con el contenido descifrado del archivo.
    """
    try:
        buffer = BytesIO()  # Crea un buffer de BytesIO para almacenar el contenido descifrado.
        with open(archivoEncriptado, "rb") as archivoEncriptado_f:
            pyAesCrypt.decryptStream(archivoEncriptado_f, buffer, contraseña, 64 * 1024)  # Descifra el archivo y lo guarda en el buffer.
        buffer.seek(0)  # Establece el cursor del buffer al inicio.
        return buffer  # Devuelve el buffer con el contenido descifrado.
    except Exception as e:
        print(f"Error al descifrar el archivo: {e}")
        return None

def cargarVariablesEntorno(buffer):
    """
    Carga las variables de entorno desde un buffer.

    Parameters:
    buffer (BytesIO): Buffer con el contenido de las variables de entorno.

    Returns:
    bool: True si las variables de entorno se cargaron correctamente, False si hubo un error.
    """
    activado = False
    try:
        for linea in buffer:
            linea = linea.decode('utf-8').strip()  # Decodifica la línea del buffer a formato UTF-8 y elimina espacios en blanco.
            partes = linea.split('=')  # Divide la línea en partes usando '=' como separador.
            if len(partes) == 2:
                os.environ[partes[0]] = partes[1]  # Establece la variable de entorno usando os.environ.
                print(f"Variable de entorno establecida: {partes[0]}")
                activado = True
    except Exception as e:
        print(f"Error al cargar las variables de entorno: {e}")
        activado = False
    return activado

print("Escribe la contraseña:")
contraseña = getpass()  # Captura segura de la contraseña utilizando getpass.

archivoEncriptado = "DNIEX.env.aes"  # Nombre del archivo encriptado.

buffer = descifrarArchivoBuffer(archivoEncriptado, contraseña)  # Descifra el archivo y obtiene el buffer con el contenido.
if buffer:
    activado = cargarVariablesEntorno(buffer)  # Carga las variables de entorno desde el buffer.
else:
    print("No se pudo descifrar el archivo.")
    exit(1)  # Sale del script con código de error si no se puede descifrar el archivo.

if not activado:
    print("No se pasó correctamente la contraseña")
    exit(1)  # Sale del script con código de error si no se pudieron cargar las variables de entorno correctamente.

print("Iniciando el servidor Django...")

# Comandos para ejecutar operaciones de Django
os.system("python manage.py makemigrations")  # Crea migraciones de la base de datos.
os.system("python manage.py migrate")  # Aplica las migraciones a la base de datos.
os.system("python manage.py runserver")  # Inicia el servidor Django.

# Ejemplo de otro posible comando para iniciar el servidor Django con host especificado:
# os.system("python manage.py runserver 0.0.0.0:8000")
