import pyAesCrypt

print("escribe la contraseña:")
password = input()
# encrypt
pyAesCrypt.encryptFile("DNIEX.env", "DNIEX.env.aes", password)