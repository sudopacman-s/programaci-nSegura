import subprocess  # Importa el módulo subprocess para ejecutar comandos del sistema.
import os  # Importa el módulo os para interactuar con el sistema operativo.
import sys  # Importa el módulo sys para manejar argumentos de línea de comandos.

def iniciador(programaEvaluar, casos):
    """
    Función para iniciar la evaluación de un programa en un contenedor Docker.

    Parameters:
    programaEvaluar (str): Ruta al programa a evaluar.
    casos (str): Ruta al archivo de casos de prueba.
    """
    nombre_programa = os.path.abspath(programaEvaluar)  # Obtiene la ruta absoluta del programa a evaluar.
    nombre_casos = os.path.abspath(casos)  # Obtiene la ruta absoluta del archivo de casos de prueba.
    nombre_imagen = "evaluador"  # Nombre de la imagen Docker.

    ruta_programa = nombre_programa  # Ruta completa del programa a evaluar.
    ruta_casos = nombre_casos  # Ruta completa del archivo de casos.

    print(ruta_programa)  # Imprime la ruta del programa a evaluar.

    # Verifica si los archivos existen.
    if not os.path.isfile(ruta_programa):
        print(f"El archivo de programa {ruta_programa} no existe.")  # Mensaje de error si el archivo de programa no existe.
        return

    if not os.path.isfile(ruta_casos):
        print(f"El archivo de casos {ruta_casos} no existe.")  # Mensaje de error si el archivo de casos no existe.
        return

    try:
        # Verifica si la imagen Docker ya está construida.
        print(f"Verificando si la imagen {nombre_imagen} ya está construida...")
        subprocess.run(["docker", "image", "inspect", nombre_imagen], check=True, capture_output=True)
        print(f"Imagen {nombre_imagen} encontrada.")  # Mensaje si la imagen Docker ya existe.
    except subprocess.CalledProcessError:
        # Si no está construida, construye la imagen.
        print(f"Imagen {nombre_imagen} no encontrada. Construyendo la imagen...")
        try:
            subprocess.run(["docker", "build", "-t", nombre_imagen, "."], check=True)
            print(f"Imagen {nombre_imagen} construida correctamente.")  # Mensaje si la imagen Docker se construye correctamente.
        except subprocess.CalledProcessError as e:
            print(f"Error al construir la imagen {nombre_imagen}: {e.stderr.strip()}")  # Mensaje de error si la construcción falla.
            return

    try:
        # Ejecuta el contenedor Docker.
        print(f"Ejecutando el contenedor {nombre_imagen}-container...")
        # Define el comando Docker para ejecutar el programa evaluador dentro del contenedor.
        comando_docker = ["docker", "run", "--rm", "-v", f"{os.getcwd()}:/evaluador",
                          nombre_imagen, "python", "evaluador.py",
                          f"/evaluador/{os.path.basename(ruta_programa)}",
                          f"/evaluador/{os.path.basename(ruta_casos)}"]
        print(f"Comando Docker: {' '.join(comando_docker)}")  # Imprime el comando Docker que se ejecutará.
        resultado = subprocess.run(comando_docker, check=True, capture_output=True, text=True)
        print(f"Salida del contenedor:\n{resultado.stdout}")  # Imprime la salida del contenedor Docker.

        # Procesa la salida como una lista de resultados.
        try:
            resultados = eval(resultado.stdout.strip())  # Evalúa la salida como una lista de Python.
            num_true = resultados.count(True)  # Cuenta cuántos resultados son True.
            return num_true  # Devuelve el número de resultados True.
        except (SyntaxError, ValueError) as e:
            print(f"Error al procesar la salida del contenedor: {e}")  # Mensaje de error si la salida no se puede procesar.

    except subprocess.CalledProcessError as e:
        if e.stderr:
            print(f"Error al ejecutar el contenedor {nombre_imagen}-container: {e.stderr.strip()}")  # Mensaje de error si hay salida estándar de error.
        else:
            print(f"Error al ejecutar el contenedor {nombre_imagen}-container: {e}")  # Mensaje de error genérico.

if __name__ == "__main__":
    # Verifica si se han proporcionado suficientes argumentos desde la línea de comandos.
    if len(sys.argv) < 3:
        print("Uso: python iniciador.py <ruta_programa> <ruta_casos>")
        sys.exit(1)  # Sale del script con código de error si no se proporcionan suficientes argumentos.

    # Llama a la función iniciador con los argumentos proporcionados desde la línea de comandos.
    iniciador(sys.argv[1], sys.argv[2])
