from plataforma import settings  # Importa la configuración de la aplicación `plataforma`.
import datetime  # Importa el módulo `datetime` para trabajar con fechas y horas.
from django.utils.timezone import make_aware  # Importa la función `make_aware` para manejar zonas horarias.
import os  # Importa el módulo `os` para interactuar con el sistema de archivos.

def crearArchivosDirectorios(identificador, usuario, entrada1, entrada2, entrada3, salida1, salida2, salida3):
    """
    Crea un archivo en un directorio basado en la fecha actual y escribe entradas y salidas en él.

    Parameters:
    identificador (str): Identificador para el archivo.
    usuario (str): Nombre de usuario.
    entrada1 (str), entrada2 (str), entrada3 (str): Entradas a escribir en el archivo.
    salida1 (str), salida2 (str), salida3 (str): Salidas a escribir en el archivo.
    """
    # Obtiene la fecha actual en formato "YYYY-MM-DD" y la convierte a la zona horaria correcta.
    fecha_actual = make_aware(datetime.datetime.now()).strftime("%Y-%m-%d")
    # Construye la ruta del directorio usando la base del proyecto y la fecha actual.
    directorio = os.path.join(settings.BASE_DIR, 'casosActividades', fecha_actual)
    if not os.path.exists(directorio):
        os.makedirs(directorio)  # Crea el directorio si no existe.

    # Construye el nombre del archivo usando el identificador, el usuario y la fecha actual.
    archivo_nombre = f"{identificador}_{usuario}_{fecha_actual}.txt"
    archivo_ruta = os.path.join(directorio, archivo_nombre)  # Construye la ruta completa del archivo.

    # Abre el archivo en modo de escritura y escribe las entradas y salidas en él.
    with open(archivo_ruta, 'w') as archivo:
        archivo.write(f"\n{entrada1}\n!!!!!!\n\n{salida1}\n$$$$$$\n")
        archivo.write(f"\n{entrada2}\n!!!!!!\n\n{salida2}\n$$$$$$\n")
        archivo.write(f"\n{entrada3}\n!!!!!!\n\n{salida3}\n$$$$$$\n")
