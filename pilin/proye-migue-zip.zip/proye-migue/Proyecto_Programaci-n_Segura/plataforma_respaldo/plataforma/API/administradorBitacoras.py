import sys
import logging
from datetime import datetime
import os

# Configuración del logging con el nombre de archivo basado en la fecha actual
fecha_actual = datetime.now().strftime('%Y-%m-%d')
directorio_log = os.path.join('Bitacoras')
if not os.path.exists(directorio_log):
    os.makedirs(directorio_log)

nombre_archivo_log = os.path.join(directorio_log, f'Bitacora_{fecha_actual}.log')

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s',
                    datefmt='%d-%b-%y %H:%M:%S', level=logging.INFO,
                    filename=nombre_archivo_log, filemode='a')

def registrarMensaje(mensaje, nivel):
    """
    Registra un mensaje como info o error en base al nivel proporcionado.

    Parameters:
    mensaje (str): El mensaje a registrar.
    nivel (int): El nivel de log. 0 para info, 1 para error.
    """
    if nivel == 0:
        logging.info(mensaje)
    elif nivel == 1:
        logging.error(mensaje)
    else:
        logging.error(f'Nivel de log inválido: {nivel}')