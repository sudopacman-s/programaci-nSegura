from baseDeDatos import models  # Importa los modelos definidos en la aplicación `baseDeDatos`.
from django.core.exceptions import ObjectDoesNotExist  # Importa la excepción `ObjectDoesNotExist` de Django.

def comprobacion(usuarioEntrada):
    """
    Comprueba si el usuario dado es un alumno o un maestro.

    Parameters:
    usuarioEntrada (str): El nombre de usuario a comprobar.

    Returns:
    models.Alumno o models.Maestro o None: Devuelve el modelo correspondiente si el usuario es un alumno o maestro, 
    o None si no se encuentra el usuario.
    """
    try:
        # Intenta obtener un objeto Alumno cuyo campo 'usuario' coincida con 'usuarioEntrada'.
        alumno = models.Alumno.objects.get(usuario=usuarioEntrada)
        return models.Alumno  # Si se encuentra, devuelve el modelo Alumno.
    except models.Alumno.DoesNotExist:
        pass  # Si no se encuentra un alumno con ese usuario, continúa con el siguiente bloque.

    try:
        # Intenta obtener un objeto Maestro cuyo campo 'usuario' coincida con 'usuarioEntrada'.
        maestro = models.Maestro.objects.get(usuario=usuarioEntrada)
        return models.Maestro  # Si se encuentra, devuelve el modelo Maestro.
    except models.Maestro.DoesNotExist:
        return None  # Si no se encuentra un maestro con ese usuario, devuelve None.
