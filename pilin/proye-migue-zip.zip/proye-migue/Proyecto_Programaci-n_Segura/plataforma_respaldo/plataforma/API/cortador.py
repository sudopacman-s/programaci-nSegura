def separador(cadenaEntrada) -> str:
    """
    Separa y devuelve el nombre del modelo de una cadena dada.

    Parameters:
    cadenaEntrada (str): La cadena de entrada que contiene el nombre del modelo.

    Returns:
    str: El nombre del modelo extraído de la cadena.
    """
    cadena = cadenaEntrada  # Asigna la cadena de entrada a la variable `cadena`.
    # Divide la cadena en 'models.' y toma la segunda parte, luego divide por el carácter "'" y toma la primera parte.
    separado = cadena.split('models.')[1].split("'")[0]
    return separado  # Devuelve el nombre del modelo separado.
