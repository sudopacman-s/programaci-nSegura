from plataforma import settings  # Importa la configuración de la aplicación `plataforma`.
import datetime  # Importa el módulo `datetime` para trabajar con fechas y horas.
from django.utils.timezone import make_aware  # Importa la función `make_aware` para manejar zonas horarias.
import os  # Importa el módulo `os` para interactuar con el sistema de archivos.
import shutil  # Importa el módulo `shutil` para operaciones de alto nivel en archivos y colecciones de archivos.

def eliminarRespuestas(respuesta):
    """
    Elimina un archivo de respuesta y su directorio asociado.

    Parameters:
    respuesta (str): La ruta relativa del archivo de respuesta a eliminar.
    """
    archivo_subido_rel = respuesta  # Asigna la ruta del archivo de respuesta a una variable.
    
    # Eliminar el archivo subido si existe.
    if os.path.exists(archivo_subido_rel):
        os.remove(archivo_subido_rel)  # Elimina el archivo.
    
    # Obtener y eliminar el directorio de la respuesta si está definido.
    directorio_respuesta = os.path.dirname(archivo_subido_rel)  # Obtiene el directorio que contiene el archivo.
    if os.path.exists(directorio_respuesta) and os.path.isdir(directorio_respuesta):
        shutil.rmtree(directorio_respuesta)  # Elimina el directorio y todo su contenido.

def eliminarEjercicio(fechaInicio, ejercicio_id, maestro_id):
    """
    Elimina el archivo de entradas de un ejercicio y su directorio asociado.

    Parameters:
    fechaInicio (datetime): La fecha de inicio del ejercicio.
    ejercicio_id (int): El ID del ejercicio.
    maestro_id (int): El ID del maestro.
    """
    # Construir la ruta relativa del archivo de entradas del ejercicio.
    archivo_entradas_rel = os.path.join('casosActividades', fechaInicio.strftime('%Y-%m-%d'), f"{ejercicio_id}_{maestro_id}_{fechaInicio.strftime('%Y-%m-%d')}.txt")

    # Eliminar el archivo de entradas si existe.
    if os.path.exists(archivo_entradas_rel):
        os.remove(archivo_entradas_rel)  # Elimina el archivo.
    
    # Obtener y eliminar el directorio del ejercicio si está definido.
    directorio_ejercicio = os.path.dirname(archivo_entradas_rel)  # Obtiene el directorio que contiene el archivo.
    if os.path.exists(directorio_ejercicio) and os.path.isdir(directorio_ejercicio):
        shutil.rmtree(directorio_ejercicio)  # Elimina el directorio y todo su contenido.
