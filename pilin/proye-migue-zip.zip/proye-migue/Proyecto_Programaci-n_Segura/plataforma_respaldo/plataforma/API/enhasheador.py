import hashlib
import base64

def password_valido(nueva_pass: str, hash_guardado: str) -> bool:
    """
    Determina si la nueva contraseña coincide con el hash guardado.

    nueva_pass: str, nueva contraseña a verificar
    hash_guardado: str, hash de la contraseña almacenada
    returns: bool, True si la nueva contraseña coincide con el hash guardado
    """
    _, algoritmo, salt, _ = hash_guardado.split('$')
    hash_obj = hashlib.sha512()
    hash_obj.update(nueva_pass.encode('utf-8') + base64.b64decode(salt))
    nuevo_hash = '$%s$%s$%s' % (algoritmo, salt, hash_obj.hexdigest())
    print(nuevo_hash)
    return nuevo_hash == hash_guardado

# Simulamos una contraseña existente almacenada en la base de datos
hash_guardado = '$6$wLn3hfSJdxalxrpH$289690308b4e2544586eb95a2ff4c26f5c443f9046fad9d121b427406a4c2105dc2cfca1c8d6d493da533a199e6c2045ec626e23146aaeb60e8c81c1407b1551'

# Solicitamos al usuario que escriba la nueva contraseña
nueva_password = input("Escribe tu nueva contraseña: ")

# Verificamos si la nueva contraseña coincide con el hash guardado
if password_valido(nueva_password, hash_guardado):
    print("La contraseña coincide con la contraseña almacenada.")
else:
    print("La contraseña no coincide con la contraseña almacenada.")
