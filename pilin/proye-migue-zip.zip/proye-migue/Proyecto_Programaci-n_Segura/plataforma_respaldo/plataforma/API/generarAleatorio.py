import requests  # Importa el módulo `requests` para hacer solicitudes HTTP.
import random  # Importa el módulo `random` para generar números aleatorios.
import base64  # Importa el módulo `base64` para codificación y decodificación de datos.
import os  # Importa el módulo `os` para interactuar con el sistema de archivos y generar bytes aleatorios.

def aleatorizar(vueltas: int) -> str:
    """
    Genera un token aleatorio realizando un número especificado de vueltas.

    Parameters:
    vueltas (int): El número de vueltas para generar un token aleatorio.

    Returns:
    str: El token generado automáticamente.
    """
    for _ in range(vueltas):
        p = os.urandom(20)  # Genera 20 bytes aleatorios.
        token = base64.urlsafe_b64encode(p).rstrip(b'=').decode('utf-8')  # Codifica los bytes en base64 seguro para URL y elimina los caracteres '='.
        # Reemplaza '_' y '-' por caracteres seguros.
        token = token.replace('_', '').replace('-', '')
    
    return token  # Devuelve el token generado.

def creadorIdentificador():
    """
    Crea un identificador aleatorio basado en un número aleatorio de vueltas.

    Returns:
    str: El identificador generado.
    """
    numeroVueltas = random.randint(1, 5)  # Genera un número aleatorio entre 1 y 5 para determinar las vueltas.
    #!DEBUG
    #print(numeroVueltas)  # Imprime el número de vueltas para fines de depuración.
    token = aleatorizar(numeroVueltas)  # Genera el token aleatorio llamando a la función `aleatorizar`.
    #print(token)  # Imprime el token generado para fines de depuración.
    return token  # Devuelve el token generado.

