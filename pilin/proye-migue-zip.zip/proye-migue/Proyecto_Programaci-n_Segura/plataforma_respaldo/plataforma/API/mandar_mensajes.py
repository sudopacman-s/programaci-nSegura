import requests
import random
import base64
import os

# Agregar esta información por usuario como parte de su registro
TOKEN = '6732706783:AAHi5svBmjXoCozzXhoU84DuhmUJSIdgFD4'

URL = 'https://api.telegram.org/bot%s/sendMessage?chat_id=%s&text=%s'

def aleatorizar(vueltas: int) -> int:
    """
    Envía el mensaje establecido al bot configurado en las
    variables constantes.

    vueltas: int, es el numero de vueltas que se va a realizar para generar un token aleatorio
    returns: char, es el token generado automaticamente
    """
    for _ in range(vueltas):
        p = os.urandom(12)
        token = base64.urlsafe_b64encode(p).rstrip(b'=').decode('utf-8')
    
    return token

def enviar_mensaje(chat: int) -> bool:
    """
    Envía el mensaje establecido al bot configurado en las
    variables constantes.

    chat: int, es el id del chat de telegram
    returns: bool, True si se pudo mandar el mensaje, False de lo contrario
    """
    try:
        numeroVueltas=random.randint(1, 5)
        #!DEBUG
        #*print(numeroVueltas)
        token=aleatorizar(numeroVueltas)
        respuesta = requests.get(URL %
                                 (TOKEN, chat, token))       
        if not respuesta.status_code == 200:
            return False
        #!DEBUG
        print(token)
        return token
    except:
        return False
