from plataforma import settings  # Importa la configuración de la aplicación `plataforma`.
import requests  # Importa el módulo `requests` para hacer solicitudes HTTP.

def verificarCaptcha(captcha):
    """
    Verifica la respuesta de reCAPTCHA con la API de Google.

    Parameters:
    captcha (str): El token de respuesta generado por el reCAPTCHA del usuario.

    Returns:
    dict: El resultado de la verificación del captcha en formato JSON.
    """
    
    # Datos para la verificación de reCAPTCHA.
    datosVerificacion = {
        'secret': settings.RECAPTCHA_PRIVATE_KEY,  # Tu clave secreta de reCAPTCHA.
        'response': captcha  # El token de respuesta del captcha proporcionado por el usuario.
    }

    # Envía una solicitud POST a la API de verificación de reCAPTCHA de Google.
    respuesta = requests.post('https://www.google.com/recaptcha/api/siteverify', data=datosVerificacion)
    
    # Convierte la respuesta en formato JSON.
    resultadoCaptcha = respuesta.json()
    
    # Devuelve el resultado de la verificación.
    return resultadoCaptcha
