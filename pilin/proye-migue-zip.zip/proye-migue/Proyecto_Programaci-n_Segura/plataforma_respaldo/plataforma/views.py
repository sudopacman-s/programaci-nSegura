from django.http import HttpResponse
from datetime import datetime
from django.shortcuts import render, redirect
from baseDeDatos import models
from django.core.exceptions import ValidationError
from django.utils.html import escape 
from django.core.validators import MaxLengthValidator
from plataforma import settings
from django.urls import reverse
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from django.utils.timezone import make_aware
import os
import shutil
import subprocess

#? Son librerias o API de scripts desarrollados segun su uso
#* Hashea las contraseñas que recibe en texto plano y regresa un hash de esta basada en sha512 y un salt
from plataforma.API import hasheador
#* Manda o envia el token a un contacto/chat de telegram para el proceso de autenticacion en 2 pasos
from plataforma.API import mandar_mensajes
#* Compara el hash almacenado en la base de datos con el hash de la contraseña que se recibe para la autenticacion
from plataforma.API import comparador
#* Utilidades para revisar la ip publica, calcular y verificar el numero de intentos, tambien si puede o no intentar
from plataforma.API import utilidades
#* Se encarga de realizar la verificacion de la informacion obtenida en el CAPTCHA
from plataforma.API import verificacionCaptcha
#* Se encarga de comprobar que tipo de usuario maestro/estudiante esta asociado el usuario de entrada
from plataforma.API import comprobadorUsuario
#* Se encarga de comprobar que tipo de usuario maestro/estudiante esta asociado el usuario de entrada
from plataforma.API import comprobadorUsuario
#* Se encarga de cortar para sacar una cadena de asociacion para dividir el login de maestro a alumno
from plataforma.API import cortador
#* Se generar caracteres aleatorios de una longitud de 28, pueden ser utilizados como identificadores
from plataforma.API import generarAleatorio
#* Genera Bitacoras o un Log en base a la fecha y al tipo de bitacora ya sea de error o de informacion
from plataforma.API import administradorBitacoras
#* Elimina los casos en base de los ejercicios y los archivos
from plataforma.API import eliminarRegistroEjercicio

#def Registro(request):
#    """
#    Registra un nuevo usuario en el sistema a través de una solicitud POST.
#
#    Si la solicitud es POST, verifica y procesa los datos del formulario para crear un nuevo usuario.
#    Si falta algún campo obligatorio o hay errores, muestra un mensaje de error correspondiente.
#    Si la solicitud no es POST, renderiza la página de registro.
#
#    Parameters:
#    - request (HttpRequest): La solicitud HTTP recibida.
#
#    Returns:
#    - HttpResponse: Una respuesta HTTP que puede ser una página de registro con un mensaje de error o una redirección a '/login'.
#    """
#    if request.method == 'POST':
#        matricula = escape(request.POST.get('matricula', ''))
#        nombre = escape(request.POST.get('nombre',''))
#        apellidos = escape(request.POST.get('apellidos',''))
#        usuarioEntrada = escape(request.POST.get('usuario',''))
#        contraseña = escape(request.POST.get('contraseña',''))
#        chat = escape(request.POST.get('chat',''))
#
#        usuario=usuarioEntrada.upper()
#
#        # Verifica si todos los campos obligatorios están presentes
#        if matricula and nombre and apellidos and usuario and contraseña and chat:
#            # Verifica la seguridad de la contraseña
#            if len(contraseña) < 10:
#                error = "La contraseña debe tener al menos 10 caracteres."
#                administradorBitacoras.registrarMensaje("Se intento crear un usuario",1)
#                return render(request, 'registro.html', {'error': error})
#            try:
#                # Verifica la seguridad de la contraseña
#                validate_password(contraseña)
#            except ValidationError as e:
#                error = " ".join(e.messages)
#                administradorBitacoras.registrarMensaje("Se intento crear un usuario",1)
#                return render(request, 'registro.html', {'error': error})
#
#            try:
#                # Verifica si el nombre de usuario ya está en uso
#                usuario_existente = models.Alumno.objects.get(usuario=usuario)
#                usuario_existente_2 = models.Maestro.objects.get(usuario=usuario)
#                error = "El nombre de usuario ya está en uso. Por favor, elige otro."
#                administradorBitacoras.registrarMensaje("Se intento crear un usuario",1)
#                return render(request, 'registro.html', {'error': error})
#            except models.Alumno.DoesNotExist:
#                try:
#                    # Intenta convertir el valor de chat en un entero
#                    chat = int(chat)
#                    if chat <= 0:
#                        error = "El valor para el campo 'chat' debe ser un número entero positivo."
#                        return render(request, 'registro.html', {'error': error})
#                except ValueError:
#                    # Si no se puede convertir a entero, muestra un mensaje de error
#                    error = "El valor para el campo 'chat' debe ser un número entero."
#                    administradorBitacoras.registrarMensaje("Se intento crear un usuario",1)
#                    return render(request, 'registro.html', {'error': error})
#                # Hashea la contraseña antes de guardarla en la base de datos
#                contraseña_hasheada=hasheador.hashing(contraseña)
#                #print(contraseña_hasheada)
#                # Crea un nuevo usuario en la base de datos
#                nuevo_usuario = models.Alumno.objects.create(matricula=matricula,
#                                                       nombre=nombre,
#                                                       apellidos=apellidos,
#                                                       usuario=usuario,
#                                                       contrasena=contraseña_hasheada, chat=chat)
#
#                # Realiza cualquier otra acción necesaria, como enviar un correo electrónico de confirmación
#                # o redirigir al usuario a una página de éxito.
#                administradorBitacoras.registrarMensaje("Se creo un usuario",0)
#                return redirect('/login')
#        else:
#            # Si falta algún campo obligatorio, muestra un mensaje de error o redirige a la página de registro con un mensaje de error
#            error = "Por favor, complete todos los campos obligatorios."
#            administradorBitacoras.registrarMensaje("Se intento crear un usuario",1)
#            return render(request, 'registro.html', {'error': error})
#    else:
#        return render(request, 'registro.html')
def Registro(request):
    """
    Registra un nuevo usuario en el sistema a través de una solicitud POST.

    Si la solicitud es POST, verifica y procesa los datos del formulario para crear un nuevo usuario.
    Si falta algún campo obligatorio o hay errores, muestra un mensaje de error correspondiente.
    Si la solicitud no es POST, renderiza la página de registro.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponse: Una respuesta HTTP que puede ser una página de registro con un mensaje de error o una redirección a '/login'.
    """
    if request.method == 'POST':
        matricula = escape(request.POST.get('matricula', '')).replace(' ', '')
        nombre = escape(request.POST.get('nombre', '')).replace(' ', '-')
        apellidos = escape(request.POST.get('apellidos', '')).replace(' ', '-')
        usuarioEntrada = escape(request.POST.get('usuario', '')).replace(' ', '')
        contraseña = escape(request.POST.get('contraseña', '')).replace(' ', '')
        chat = escape(request.POST.get('chat', '')).replace(' ', '')

        usuario = usuarioEntrada.upper()

        # Verifica si todos los campos obligatorios están presentes
        if matricula and nombre and apellidos and usuario and contraseña and chat:
            # Verifica la seguridad de la contraseña
            if len(contraseña) < 10:
                error = "La contraseña debe tener al menos 10 caracteres."
                administradorBitacoras.registrarMensaje("Se intento crear un usuario", 1)
                return render(request, 'registro.html', {'error': error})
            try:
                # Verifica la seguridad de la contraseña
                validate_password(contraseña)
            except ValidationError as e:
                error = " ".join(e.messages)
                administradorBitacoras.registrarMensaje("Se intento crear un usuario", 1)
                return render(request, 'registro.html', {'error': error})

            # Verifica si la matrícula ya está en uso
            if models.Alumno.objects.filter(matricula=matricula).exists():
                error = "La matrícula ya está en uso. Por favor, elige otra."
                administradorBitacoras.registrarMensaje("Se intento crear un usuario con matrícula duplicada", 1)
                return render(request, 'registro.html', {'error': error})

            # Verifica si el nombre de usuario ya está en uso en la tabla Alumno o Maestro
            if models.Alumno.objects.filter(usuario=usuario).exists() or models.Maestro.objects.filter(usuario=usuario).exists():
                error = "El nombre de usuario ya está en uso. Por favor, elige otro."
                administradorBitacoras.registrarMensaje("Se intento crear un usuario", 1)
                return render(request, 'registro.html', {'error': error})

            # Valida el campo 'chat' para permitir solo números y guiones
            if not re.match(r'^[0-9\-]+$', chat):
                error = "El valor para el campo 'chat' debe contener solo números y guiones."
                administradorBitacoras.registrarMensaje("Se intento crear un usuario", 1)
                return render(request, 'registro.html', {'error': error})

            # Hashea la contraseña antes de guardarla en la base de datos
            contraseña_hasheada = hasheador.hashing(contraseña)

            # Crea un nuevo usuario en la base de datos
            nuevo_usuario = models.Alumno.objects.create(
                matricula=matricula,
                nombre=nombre,
                apellidos=apellidos,
                usuario=usuario,
                contrasena=contraseña_hasheada,
                chat=chat
            )

            # Realiza cualquier otra acción necesaria, como enviar un correo electrónico de confirmación
            administradorBitacoras.registrarMensaje("Se creo un usuario", 0)
            return redirect('/login')
        else:
            # Si falta algún campo obligatorio, muestra un mensaje de error
            error = "Por favor, complete todos los campos obligatorios."
            administradorBitacoras.registrarMensaje("Se intento crear un usuario", 1)
            return render(request, 'registro.html', {'error': error})
    else:
        return render(request, 'registro.html')
#???????????????????????????????????????????????????????????????????????????????????????????????#
#?                                                                                             ?#
#?                               AQUI EMPIEZAN LAS VISTAS DE MAESTROS                          ?#
#?                                                                                             ?#
#???????????????????????????????????????????????????????????????????????????????????????????????#

def Login(request):
    """
    Maneja el proceso de inicio de sesión de usuarios.

    Si la sesión ya está activa ('logueo' en la sesión), redirige al usuario a la página de inicio.
    Si la solicitud es GET, muestra el formulario de inicio de sesión con la IP del cliente y la clave pública de reCAPTCHA.
    Si la solicitud es POST, verifica las credenciales ingresadas y realiza las validaciones necesarias.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponse: Una respuesta HTTP que puede ser una página de inicio, un formulario de inicio de sesión con errores o un mensaje de error si el método no es soportado.
    """
    if 'logueo' in request.session:
        return redirect('/inicio')  # Redirige a la página de inicio si el usuario ya está autenticado
    if request.method == 'GET':
        ip = utilidades.get_client_ip(request)        
        return render(request, 'login.html') #, {'ip': ip, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    elif request.method == 'POST':
        ip = utilidades.get_client_ip(request)
        if not utilidades.puede_loguearse(request):
            error = 'Agotaste tu límite de intentos, debes esperar %s segundos' % settings.LIMITE_SEGUNDOS_LOGIN
            administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
            return render(request, 'login.html') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        usuarioMinus = escape(request.POST.get('usuario', ''))
        contra = escape(request.POST.get('contrasena', ''))
        #captcha = request.POST.get('g-recaptcha-response')
        
        usuarioEntrada=usuarioMinus.upper()

        #if not captcha:
            #administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
            #error = 'Por favor, completa el CAPTCHA.'
            #return render(request, 'login.html', {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        
        #resultadoCaptcha=verificacionCaptcha.verificarCaptcha(captcha)
        
        #if not resultadoCaptcha['success']:
            #error = 'Falló la verificación CAPTCHA.'
            #administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
            #return render(request, 'login.html', {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        
        #!DEBUG
        #*print(usuarioEntrada)

        tablaAsociada=comprobadorUsuario.comprobacion(usuarioEntrada)
        
        #!DEBUG
        #*print(tablaAsociada)

        if tablaAsociada is None:
            error = 'El Usuario No Existe'
            administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
            return render(request, 'login.html') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

        try:
            #!DEBUG
            #*print(tablaAsociada)

            comprabacionUsuario=tablaAsociada.objects.get(usuario=usuarioEntrada)

            #!DEBUG
            #*print(comprabacionUsuario)

            if comparador.comparar_hashes(comprabacionUsuario.contrasena,contra):
                cliente = models.Intentos.objects.get(ip=ip)
                utilidades.actualizar_info_cliente(cliente, 0)
                resultado = mandar_mensajes.enviar_mensaje(comprabacionUsuario.chat)

                asociacion=cortador.separador(str(tablaAsociada))
                #!DEBUG
                #*print("Resultado:", asociacion)

                # Obtener el token de la salida del proceso
                tokenResultado = resultado
                
                #!DEBUG
                #*print("Token generado:", tokenResultado)

                #!DEBUG
                #*print(tokenResultado)
                #*print(comprabacionUsuario.usuario)

                request.session['logueo'] = {'origen': asociacion,'usuario': comprabacionUsuario.usuario, 'token': tokenResultado}
                
                request.session['tiempoDVida'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                administradorBitacoras.registrarMensaje(f"Se inicio sesion desde la IP {ip}",0)

                return redirect('/confirmacion')
            else:
                error = 'Credenciales inválidas'
                administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
                return render(request, 'login.html') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        except tablaAsociada.DoesNotExist:
            error = 'El Usuario No Existe'
            administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
            return render(request, 'login.html') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    else:
        error = "Método no soportado"
        administradorBitacoras.registrarMensaje(f"Fallo el inicio sesion desde la IP {ip} error: {error}",1)
        return render(request, 'login.html') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def verificacionToken(request):
    """
    Verifica el token ingresado por el usuario para completar el proceso de verificación.

    Si la sesión de usuario ('logueo') y el tiempo de vida ('tiempoDVida') están presentes en la sesión,
    verifica el token ingresado y redirige al usuario a la página de inicio si la verificación es exitosa.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponse: Una respuesta HTTP que puede ser una redirección a la página de inicio, un mensaje de error si el token es incorrecto o ha expirado, o la página de verificación de token si no se ha completado la verificación.
    """
    if 'logueo' in request.session and 'tiempoDVida' in request.session:
        if request.method == 'POST':
            token_ingresado = request.POST.get('token', '')
            contenido_sesion = request.session['logueo']
            token = contenido_sesion['token']
            usuario = contenido_sesion['usuario']
            caducidad = datetime.strptime(request.session['tiempoDVida'], '%Y-%m-%d %H:%M:%S')

            # Verifica si el token aún es válido (dentro de los 2 minutos de caducidad)
            if (datetime.now() - caducidad).seconds <= 120:
                if token_ingresado == token:
                    # Actualiza el token en la sesión para usar el valor original (origen)
                    datoSesion = request.session.get('logueo', {})
                    datoSesion['token'] = datoSesion['origen']

                    # Guarda los cambios en la sesión
                    request.session['logueo'] = datoSesion

                    administradorBitacoras.registrarMensaje(f"Completo la verificacion en el usuario {usuario}", 0)

                    return redirect('/inicio')
                else:
                    # Si el token es incorrecto, devuelve al usuario a la página de inicio de sesión con un mensaje de error
                    error = "Token incorrecto"
                    administradorBitacoras.registrarMensaje(f"Fallo la verificacion en el usuario {usuario} error: {error}", 1)
                    return render(request, 'login.html') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
            else:
                # Si el token ha expirado, devuelve al usuario a la página de inicio de sesión con un mensaje de error
                error = "El token ha expirado, por favor repita el trámite"
                administradorBitacoras.registrarMensaje(f"Fallo la verificacion en el usuario {usuario} error: {error}", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        else:
            # Método GET: muestra la página de verificación de token
            return render(request, 'verificacionToken.html')
    else:
        # La sesión no está definida o ha expirado, devuelve al usuario a la página de inicio de sesión
        error = "La Sesión Expiró"
        administradorBitacoras.registrarMensaje(f"Fallo la verificacion en el usuario {usuario} error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def Logout(request):
    """
    Cierra la sesión de usuario actual y redirige al usuario a la página de inicio de sesión.

    Revoca la sesión actual ('logueado') y borra todos los datos de sesión.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect: Redirige al usuario a la página de inicio de sesión después de cerrar la sesión.
    """
    # Revoca el estado de 'logueado' en la sesión
    request.session['logueado'] = False
    
    # Borra completamente la sesión
    request.session.flush()
    
    # Redirige al usuario a la página de inicio de sesión con la clave pública de reCAPTCHA
    return redirect('/login') #, {'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

def Inicio(request):
    """
    Maneja la vista de inicio de sesión del usuario, redirigiendo según el tipo de usuario autenticado.

    Si la sesión de 'logueo' está activa, verifica el tipo de usuario ('Maestro' o 'Alumno') y redirige a la vista correspondiente.
    Si no se puede determinar el tipo de usuario, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect: Redirige al usuario según el tipo de sesión activa o muestra un mensaje de error si la sesión no está definida o ha expirado.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica el tipo de usuario basado en el token almacenado en la sesión
        if datoSesion['token'] == "Maestro":
            administradorBitacoras.registrarMensaje(f"La Comprobacion Indica que es una Maestro", 0)
            return redirect(reverse('inicioMaestro'))  # Redirige a la vista de inicio de Maestro
        elif datoSesion['token'] == "Alumno":
            administradorBitacoras.registrarMensaje(f"La Comprobacion Indica que es una Alumno", 0)
            return redirect(reverse('inicioAlumno'))  # Redirige a la vista de inicio de Alumno
        else:
            # Si no se puede determinar el tipo de usuario, cierra la sesión y redirige con un mensaje de error
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor, inicie sesión correctamente."
            administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor, inicie sesión."
        administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def inicioMaestro(request):
    """
    Maneja la vista de inicio para un usuario tipo 'Maestro', mostrando información específica del maestro y sus ejercicios.

    Si la sesión de 'logueo' está activa y el usuario tiene el token 'Maestro', muestra la página de inicio del maestro con información sobre él y la cantidad de ejercicios que ha creado.

    Si no se puede encontrar al maestro en la base de datos, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al usuario a la página de inicio del maestro o muestra un mensaje de error si la sesión no está definida o ha expirado.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un maestro
        if datoSesion['token'] == "Maestro":
            try:
                # Intenta obtener al maestro desde la base de datos
                maestro = models.Maestro.objects.get(usuario=datoSesion['usuario'])
                numEjercicios = models.Ejercicio.objects.filter(maestro=maestro).count()
                informacion = {
                    'maestro': maestro,
                    'num_ejercicios': numEjercicios
                }
                # Renderiza la página de inicio del maestro con la información obtenida
                return render(request, 'inicioMaestro.html', informacion)
            except models.Maestro.DoesNotExist:
                # Si no se puede encontrar al maestro en la base de datos, cierra la sesión y redirige con un mensaje de error
                error = "La sesión no corresponde a un maestro válido."
                administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio error: {error}", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        else:
            # Si el token no es 'Maestro', cierra la sesión y redirige con un mensaje de error
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor, inicie sesión correctamente."
            administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor, inicie sesión."
        administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

def crearEjercicio(request):
    """
    Maneja la creación de un ejercicio por parte de un usuario tipo 'Maestro'. Verifica la sesión activa del maestro y procesa la creación del ejercicio con los datos proporcionados.

    Si la sesión de 'logueo' está activa y el usuario tiene el token 'Maestro', permite al maestro crear un ejercicio. Guarda los datos del ejercicio en la base de datos y crea un archivo con las entradas y salidas proporcionadas.

    Si no se puede encontrar al maestro en la base de datos, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al maestro a la página de creación de ejercicio con un mensaje de éxito o muestra un mensaje de error si la sesión no está definida, ha expirado o el usuario no es un maestro válido.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un maestro
        if datoSesion['token'] == "Maestro":
            try:
                # Intenta obtener al maestro desde la base de datos
                maestro = models.Maestro.objects.get(usuario=datoSesion['usuario'])
                
                # Procesa la solicitud POST para crear el ejercicio
                if request.method == 'POST':
                    # Genera un identificador aleatorio para el ejercicio
                    identificador = generarAleatorio.creadorIdentificador()
                    
                    # Obtiene los datos del formulario y los escapa para evitar inyección de código
                    nombreEjercicio = escape(request.POST.get('nombreEjercicio'))
                    descripcion = escape(request.POST.get('descripcion'))
                    entrada1 = escape(request.POST.get('entrada1'))
                    salida1 = escape(request.POST.get('salida1'))
                    entrada2 = escape(request.POST.get('entrada2'))
                    salida2 = escape(request.POST.get('salida2'))
                    entrada3 = escape(request.POST.get('entrada3'))
                    salida3 = escape(request.POST.get('salida3'))
                    entradaEjemplo = escape(request.POST.get('entradaEjemplo'))
                    salidaEjemplo = escape(request.POST.get('salidaEjemplo'))
                    fechaInicio = escape(request.POST.get('fechaInicio'))
                    fechaCierre = escape(request.POST.get('fechaCierre'))

                    # Crea el directorio para almacenar el archivo de entradas y salidas del ejercicio
                    fecha_actual = make_aware(datetime.now()).strftime("%Y-%m-%d")
                    directorio = os.path.join(settings.BASE_DIR, 'casosActividades', fecha_actual)
                    if not os.path.exists(directorio):
                        os.makedirs(directorio)
                    
                    # Define la ruta y nombre del archivo para almacenar las entradas y salidas del ejercicio
                    archivo_nombre = f"{identificador}_{maestro.usuario}_{fecha_actual}.txt"
                    archivo_ruta = os.path.join(directorio, archivo_nombre)
                    
                    # Escribe las entradas y salidas en el archivo creado
                    with open(archivo_ruta, 'w') as archivo:
                        archivo.write(f"\n{entrada1}\n!!!!!!\n\n{salida1}\n$$$$$$\n")
                        archivo.write(f"\n{entrada2}\n!!!!!!\n\n{salida2}\n$$$$$$\n")
                        archivo.write(f"\n{entrada3}\n!!!!!!\n\n{salida3}\n$$$$$$\n")

                    # Crea el ejercicio en la base de datos
                    models.Ejercicio.objects.create(
                        identificador=identificador,
                        maestro=maestro,
                        nombreEjercicio=nombreEjercicio,
                        descripcion=descripcion,
                        entrada1=entrada1,
                        salida1=salida1,
                        entrada2=entrada2,
                        salida2=salida2,
                        entrada3=entrada3,
                        salida3=salida3,
                        entradaEjemplo=entradaEjemplo,
                        salidaEjemplo=salidaEjemplo,
                        fechaInicio=fechaInicio,
                        fechaCierre=fechaCierre,
                        archivoEntradas=archivo_ruta  # Ruta absoluta del archivo
                    )

                    mensaje = "Se creó correctamente tu ejercicio"
                    administradorBitacoras.registrarMensaje(f"Se creó correctamente un ejercicio por el maestro: {maestro}", 0)
                    return render(request, 'crearEjercicio.html', {'mensaje': mensaje})
                
                else:
                    # Maneja solicitud GET para mostrar el formulario de creación de ejercicio
                    return render(request, 'crearEjercicio.html')
            
            except models.Maestro.DoesNotExist:
                # Si no se encuentra al maestro en la base de datos, cierra la sesión y redirige con un mensaje de error
                error = "La sesión no corresponde a un maestro válido."
                administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de crear error: {error}", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        
        else:
            # Si el token no es 'Maestro', cierra la sesión y redirige con un mensaje de error
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor inicie sesión correctamente como maestro."
            administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de crear error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor inicie sesión."
        administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de crear error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def listarEjercicios(request):
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        if datoSesion['token'] == "Maestro":
            try:
                maestro = models.Maestro.objects.get(usuario=datoSesion['usuario'])
                ejercicios = models.Ejercicio.objects.filter(maestro=maestro)

                if request.method == 'POST':
                    if 'nombreEjercicio' in request.POST:
                        nombreEjercicio = escape(request.POST.get('nombreEjercicio'))
                        ejercicios = ejercicios.filter(nombreEjercicio__icontains=nombreEjercicio)
                    elif 'ejercicio_id' in request.POST:
                        ejercicio_id = request.POST.get('ejercicio_id')
                        request.session['ejercicio_id'] = ejercicio_id
                        return redirect('detalle-ejercicio')

                return render(request, 'listarEjercicios.html', {'ejercicios': ejercicios})
            except models.Maestro.DoesNotExist:
                error = "La sesión no es de un Maestro"
                administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de listar error: {error}",1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        else:
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor inicie sesión correctamente"
            administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de listar error: {error}",1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    else:
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor inicie sesión"
        administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de listar error: {error}",1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def detalleEjercicio(request):
    """
    Muestra una lista de ejercicios asociados al maestro que ha iniciado sesión. Permite filtrar los ejercicios por nombre y redirige al detalle de un ejercicio específico cuando se selecciona desde la lista.

    Verifica si hay una sesión activa con el token de 'Maestro'. Si la sesión y el token son válidos, muestra todos los ejercicios creados por ese maestro. Permite filtrar los ejercicios por nombre mediante una solicitud POST y redirige al detalle del ejercicio cuando se selecciona desde la lista.

    Si no se puede encontrar al maestro en la base de datos, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al maestro a la página de listado de ejercicios con los ejercicios filtrados o muestra un mensaje de error si la sesión no está definida, ha expirado o el usuario no es un maestro válido.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un maestro
        if datoSesion['token'] == "Maestro":
            try:
                # Intenta obtener al maestro desde la base de datos
                maestro = models.Maestro.objects.get(usuario=datoSesion['usuario'])
                
                # Obtiene todos los ejercicios asociados al maestro
                ejercicios = models.Ejercicio.objects.filter(maestro=maestro)

                # Procesa la solicitud POST para filtrar ejercicios por nombre o redirigir al detalle de un ejercicio
                if request.method == 'POST':
                    if 'nombreEjercicio' in request.POST:
                        nombreEjercicio = escape(request.POST.get('nombreEjercicio'))
                        ejercicios = ejercicios.filter(nombreEjercicio__icontains=nombreEjercicio)
                    elif 'ejercicio_id' in request.POST:
                        ejercicio_id = request.POST.get('ejercicio_id')
                        request.session['ejercicio_id'] = ejercicio_id
                        return redirect('detalle-ejercicio')

                # Renderiza la página de listado de ejercicios con los ejercicios obtenidos
                return render(request, 'listarEjercicios.html', {'ejercicios': ejercicios})
            
            except models.Maestro.DoesNotExist:
                # Si no se encuentra al maestro en la base de datos, cierra la sesión y redirige con un mensaje de error
                error = "La sesión no corresponde a un Maestro válido."
                administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de listar error: {error}", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        
        else:
            # Si el token no es 'Maestro', cierra la sesión y redirige con un mensaje de error
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor inicie sesión correctamente como maestro."
            administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de listar error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor inicie sesión."
        administradorBitacoras.registrarMensaje(f"No se Comprobo bien el Inicio en la interfaz de listar error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

def listarAlumnosPorEjercicio(request):
    """
    Muestra la lista de ejercicios asociados al maestro que ha iniciado sesión y, si se ha seleccionado un ejercicio específico, muestra la lista de alumnos junto con su estado de entrega para ese ejercicio.

    Verifica si hay una sesión activa con el token de 'Maestro'. Si la sesión y el token son válidos, muestra todos los ejercicios creados por ese maestro. Si se ha seleccionado un ejercicio específico mediante una solicitud POST, guarda el ID del ejercicio en la sesión y redirige a la vista 'listar-alumnos-ejercicio'.

    Si no se puede encontrar al maestro en la base de datos, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al maestro a la página de listado de ejercicios con la lista de ejercicios y, si se ha seleccionado un ejercicio específico, muestra la lista de alumnos junto con su estado de entrega para ese ejercicio. Si la sesión no está definida, ha expirado o el usuario no es un maestro válido, redirige a la página de inicio de sesión con un mensaje de error.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un maestro
        if datoSesion['token'] == "Maestro":
            try:
                # Intenta obtener al maestro desde la base de datos
                maestro = models.Maestro.objects.get(usuario=datoSesion['usuario'])
                
                # Si se ha realizado una solicitud POST para seleccionar un ejercicio específico
                if request.method == 'POST':
                    ejercicio_id = request.POST.get('ejercicio_id')
                    request.session['ejercicio_id'] = ejercicio_id
                    return redirect('listar-alumnos-ejercicio')

                # Obtiene todos los ejercicios asociados al maestro
                ejercicios = models.Ejercicio.objects.filter(maestro=maestro)
                
                # Si se ha seleccionado un ejercicio específico
                if 'ejercicio_id' in request.session:
                    ejercicio_id = request.session['ejercicio_id']
                    ejercicio_seleccionado = models.Ejercicio.objects.get(identificador=ejercicio_id)
                    
                    # Obtiene todos los alumnos y marca si han entregado para el ejercicio seleccionado
                    alumnos = models.Alumno.objects.all()
                    alumnos_entregados = []
                    
                    for alumno in alumnos:
                        try:
                            respuesta = models.Respuesta.objects.get(ejercicio=ejercicio_seleccionado, estudiante=alumno)
                            entregado = True
                        except models.Respuesta.DoesNotExist:
                            entregado = False
                        
                        alumnos_entregados.append((alumno, entregado))
                    
                    administradorBitacoras.registrarMensaje(f"El maestro {maestro} revisó el ejercicio {ejercicio_id}", 0)

                    return render(request, 'listarEjerciciosB.html', {'ejercicios': ejercicios, 'alumnos_entregados': alumnos_entregados})
                
                # Si no se ha seleccionado un ejercicio específico, muestra solo la lista de ejercicios
                return render(request, 'listarEjerciciosB.html', {'ejercicios': ejercicios})
            
            except models.Maestro.DoesNotExist:
                # Si no se encuentra al maestro en la base de datos, cierra la sesión y redirige con un mensaje de error
                error = "La sesión no corresponde a un Maestro válido."
                administradorBitacoras.registrarMensaje(f"No se inició sesión correctamente en listarAlumnosPorEjercicio", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        
        else:
            # Si el token no es 'Maestro', cierra la sesión y redirige con un mensaje de error
            request.session.flush()
            error = "Por favor inicie sesión correctamente."
            administradorBitacoras.registrarMensaje(f"No se inició sesión correctamente en listarAlumnosPorEjercicio", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session.flush()
        error = "Por favor inicie sesión."
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

def listarAlumnosPorEjercicioDetalle(request):
    """
    Muestra los detalles de las respuestas de los alumnos para un ejercicio específico seleccionado por un maestro.

    Verifica si hay una sesión activa con el token de 'Maestro'. Si la sesión y el token son válidos, obtiene el ID del ejercicio seleccionado de la sesión. Luego, recupera todas las respuestas de los alumnos para ese ejercicio y muestra los detalles, incluyendo si cada alumno ha entregado o no el ejercicio.

    Si se realiza una solicitud POST para seleccionar un alumno específico cuya respuesta se desea ver, verifica si el alumno ha entregado el ejercicio y redirige a la vista 'detalle-respuesta-alumno'. Si el alumno no ha entregado el ejercicio, muestra un mensaje de error.

    Si el ejercicio seleccionado no existe en la base de datos, muestra un mensaje de error.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al maestro a la página de listado de alumnos con los detalles de las respuestas de los alumnos para el ejercicio seleccionado. Si la sesión no está definida, ha expirado o el usuario no es un maestro válido, redirige a la página de inicio de sesión con un mensaje de error.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un maestro
        if datoSesion['token'] == "Maestro":
            ejercicio_id = request.session.get('ejercicio_id')
            
            # Si no hay un ejercicio seleccionado, redirige para seleccionar uno
            if not ejercicio_id:
                return redirect('listar-ejercicios-alumno')

            try:
                # Intenta obtener el ejercicio desde la base de datos
                ejercicio = models.Ejercicio.objects.get(identificador=ejercicio_id)
                alumnos = models.Alumno.objects.all()
                respuestas = models.Respuesta.objects.filter(ejercicio=ejercicio)

                alumnos_respuestas = []
                
                # Itera sobre todos los alumnos para obtener sus respuestas al ejercicio
                for alumno in alumnos:
                    try:
                        respuesta = respuestas.get(estudiante_id=alumno.matricula)
                        estado = 'entregado'
                    except models.Respuesta.DoesNotExist:
                        respuesta = None
                        estado = 'no_entregado'
                    
                    alumnos_respuestas.append((alumno, respuesta, estado))

                # Si se realiza una solicitud POST para ver detalles de la respuesta de un alumno específico
                if request.method == 'POST' and 'alumno_matricula' in request.POST:
                    alumno_matricula = request.POST.get('alumno_matricula')
                    
                    # Verifica si el alumno seleccionado ha entregado el ejercicio
                    if alumno_matricula in [alumno.matricula for alumno, _, estado in alumnos_respuestas if estado == 'entregado']:
                        request.session['alumno_matricula'] = alumno_matricula
                        administradorBitacoras.registrarMensaje(f"Se comprobaron los resultados de los alumnos", 0)
                        return redirect('detalle-respuesta-alumno')
                    else:
                        error = "No puedes seleccionar a un alumno que no ha entregado el ejercicio."
                        administradorBitacoras.registrarMensaje(f"{error}", 1)
                        return render(request, 'listarAlumnosPorEjercicio.html', {'error': error})

                # Renderiza la página con los detalles de los alumnos y sus respuestas
                return render(request, 'listarAlumnosPorEjercicio.html', {'alumnos_respuestas': alumnos_respuestas})
            
            except models.Ejercicio.DoesNotExist:
                # Si el ejercicio no existe en la base de datos, muestra un mensaje de error
                error = "El ejercicio no existe."
                administradorBitacoras.registrarMensaje(f"{error}", 1)
                return render(request, 'listarAlumnosPorEjercicio.html', {'error': error})
        
        else:
            # Si el token no es 'Maestro', cierra la sesión y redirige con un mensaje de error
            request.session.flush()
            error = "Por favor inicie sesión correctamente"
            administradorBitacoras.registrarMensaje(f"Se detectó este error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session.flush()
        error = "Por favor inicie sesión"
        administradorBitacoras.registrarMensaje(f"Se detectó este error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def detalleRespuestaAlumno(request):
    """
    Muestra los detalles de la respuesta de un alumno para un ejercicio específico seleccionado por un maestro.

    Verifica si hay una sesión activa con el token de 'Maestro'. Si la sesión y el token son válidos, obtiene el ID del ejercicio y la matrícula del alumno desde la sesión. Luego, recupera la respuesta del alumno para ese ejercicio y muestra los detalles, incluyendo el contenido del archivo subido por el alumno.

    Si la respuesta del alumno no existe en la base de datos, redirige de vuelta al listado de ejercicios de alumno.

    Si la sesión no está definida o ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al maestro a la página de detalle de respuesta del alumno. Si la sesión no está definida, ha expirado o el usuario no es un maestro válido, redirige a la página de inicio de sesión con un mensaje de error.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un maestro
        if datoSesion['token'] == "Maestro":
            ejercicio_id = request.session.get('ejercicio_id')
            alumno_matricula = request.session.get('alumno_matricula')
            
            # Si no hay un ejercicio o alumno seleccionado, redirige para seleccionar uno
            if not ejercicio_id or not alumno_matricula:
                return redirect('listar-ejercicios-alumno')

            try:
                # Intenta obtener la respuesta del alumno para el ejercicio desde la base de datos
                respuesta = models.Respuesta.objects.get(ejercicio_id=ejercicio_id, estudiante_id=alumno_matricula)
                alumno = respuesta.estudiante
                
                # Construye la ruta completa al archivo subido por el alumno
                archivo_path = os.path.join(settings.BASE_DIR, 'respuestasEjercicios', ejercicio_id, os.path.basename(respuesta.archivoSubido))
                
                # Leer el contenido del archivo
                with open(archivo_path, 'r', encoding='utf-8') as archivo:
                    contenido_archivo = archivo.read()

                # Renderiza la página con los detalles de la respuesta del alumno
                return render(request, 'detalleRespuestaAlumno.html', {
                    'nombre': alumno.nombre,
                    'apellidos': alumno.apellidos,
                    'matricula': alumno.matricula,
                    'fechaSubida': respuesta.fechaSubida,
                    'puntos': respuesta.puntos,
                    'contenido_archivo': contenido_archivo,
                })
            
            except models.Respuesta.DoesNotExist:
                # Si la respuesta del alumno no existe en la base de datos, muestra un mensaje de error y redirige
                error = "La respuesta no existe."
                administradorBitacoras.registrarMensaje(f"{error}", 1)
                return redirect('listar-ejercicios-alumno')

        else:
            # Si el token no es 'Maestro', cierra la sesión y redirige con un mensaje de error
            request.session.flush()
            error = "Por favor inicie sesión correctamente"
            administradorBitacoras.registrarMensaje(f"Se intentó entrar con una sesión inválida error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session.flush()
        error = "Por favor inicie sesión"
        administradorBitacoras.registrarMensaje(f"Se intentó entrar con una sesión inválida error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

#***********************************************************************************************#
#*                                                                                             *#
#*                               AQUI EMPIEZAN LAS VISTAS DE ALUMNOS                           *#
#*                                                                                             *#
#***********************************************************************************************#

def inicioAlumno(request):
    """
    Renderiza la página de inicio del alumno si la sesión está activa y corresponde a un alumno autenticado.

    Verifica si hay una sesión activa con el token de 'Alumno'. Si la sesión y el token son válidos, obtiene los datos del alumno desde la sesión y cuenta el número de ejercicios pendientes que aún no ha completado. Renderiza la página de inicio del alumno con la información obtenida.

    Si el usuario no es un alumno válido o la sesión ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al alumno a la página de inicio si la sesión es válida y corresponde a un alumno. Si no, redirige a la página de inicio de sesión con un mensaje de error.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        
        # Verifica si el usuario tiene sesión activa y es un alumno
        if datoSesion['token'] == "Alumno":
            try:
                # Intenta obtener los datos del alumno desde la base de datos
                alumno = models.Alumno.objects.get(usuario=datoSesion['usuario'])
                
                # Calcula el número de ejercicios pendientes para el alumno
                num_ejercicios_pendientes = models.Ejercicio.objects.exclude(
                    respuesta__estudiante=alumno
                ).count()
                
                # Prepara la información a enviar a la plantilla
                informacion = {
                    'alumno': alumno,
                    'num_ejercicios_pendientes': num_ejercicios_pendientes
                }

                # Registra un mensaje de inicio de sesión en los registros
                administradorBitacoras.registrarMensaje(f"Se inició sesión como alumno: {alumno.matricula}", 0)

                # Renderiza la página de inicio del alumno con la información obtenida
                return render(request, 'inicioAlumno.html', informacion)
            
            except models.Alumno.DoesNotExist:
                # Si no existe el alumno en la base de datos, cierra la sesión y redirige con un mensaje de error
                request.session.flush()
                error = "La sesión no corresponde a un Alumno."
                administradorBitacoras.registrarMensaje(f"No existe el usuario de Alumno", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
        
        else:
            # Si el token no es 'Alumno', cierra la sesión y redirige con un mensaje de error
            request.session.flush()
            error = "Por favor, inicie sesión correctamente."
            administradorBitacoras.registrarMensaje(f"Intento de acceso con una sesión inválida error: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
    else:
        # Si la sesión no está definida o ha expirado, cierra la sesión y redirige con un mensaje de error
        request.session.flush()
        error = "Por favor, inicie sesión."
        administradorBitacoras.registrarMensaje(f"Intento de acceso con una sesión inválida error: {error}", 1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
    
def ejerciciosDisponibles(request):
    """
    Renderiza la página de ejercicios disponibles para el alumno si la sesión está activa y corresponde a un alumno autenticado.

    Verifica si hay una sesión activa con el token de 'Alumno'. Si la sesión y el token son válidos, obtiene los datos del alumno desde la sesión y filtra los ejercicios disponibles que aún no ha completado y que no están vencidos. Renderiza la página de ejercicios disponibles con la lista de ejercicios obtenida.

    Si el usuario no es un alumno válido o la sesión ha expirado, cierra la sesión y redirige a la página de inicio de sesión con un mensaje de error.

    Parameters:
    - request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    - HttpResponseRedirect o HttpResponse: Redirige al alumno a la página de ejercicios disponibles si la sesión es válida y corresponde a un alumno. Si no, redirige a la página de inicio de sesión con un mensaje de error.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        if datoSesion['token'] == "Alumno":
            try:
                alumno = models.Alumno.objects.get(usuario=datoSesion['usuario'])

                # Obtener ejercicios disponibles sin respuestas asociadas del alumno y que no estén vencidos
                ejercicios_disponibles = models.Ejercicio.objects.exclude(
                    respuesta__estudiante=alumno
                ).filter(fechaCierre__gte=make_aware(datetime.now()))

                if request.method == 'POST' and 'ejercicio_id' in request.POST:
                    ejercicio_id = request.POST.get('ejercicio_id')
                    request.session['ejercicio_id'] = ejercicio_id
                    administradorBitacoras.registrarMensaje(f"Se selecciono el siguiente ejercicio {ejercicio_id}",0)
                    return redirect('detalle-ejercicio-disponible')
                administradorBitacoras.registrarMensaje(f"Se ingreso al espacio de ejercicios Disponibles",0)
                return render(request, 'ejerciciosDisponibles.html', {'ejercicios_disponibles': ejercicios_disponibles})

            except models.Alumno.DoesNotExist:
                error = "La sesión no es de un Alumno."
                administradorBitacoras.registrarMensaje(f"Fallo el por un inicio de sesion erroneo Error:{error}",1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

        else:
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor inicie sesión correctamente."
            administradorBitacoras.registrarMensaje(f"Fallo el por un inicio de sesion erroneo Error:{error}",1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

    else:
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor inicie sesión."
        administradorBitacoras.registrarMensaje(f"Fallo el por un inicio de sesion erroneo Error:{error}",1)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

def extraer_puntos(salida_comando):
    """
    Extrae el número de puntos (ocurrencias de 'True') de una cadena de salida de comando.

    Esta función cuenta las ocurrencias de la cadena 'True' en la salida del comando proporcionada y devuelve el número total de ocurrencias como puntos.

    Parameters:
    - salida_comando (str): Cadena de salida del comando que se analiza para contar 'True'.

    Returns:
    - int: Número de puntos extraídos de la cadena de salida del comando. Retorna 0 si no se encuentra ninguna ocurrencia de 'True'.
    """
    if salida_comando.count('True'):
        return salida_comando.count('True')
    else:
        return 0

def detalleEjercicioDisponible(request):
    """
    Vista para manejar la subida de respuestas de un alumno a un ejercicio disponible.

    Permite a un alumno subir su respuesta a un ejercicio disponible, procesarla en un entorno aislado, y registrarla en la base de datos junto con los puntos obtenidos y otros detalles.

    Parameters:
    - request (HttpRequest): Objeto que contiene los datos de la solicitud HTTP.

    Returns:
    - HttpResponse: Renderiza la plantilla 'detalleEjercicioDisponible.html' con información del ejercicio y mensajes adicionales según el proceso de subida de respuesta.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        if datoSesion['token'] == "Alumno":
            ejercicio_id = request.session.get('ejercicio_id')
            if not ejercicio_id:
                return redirect('ejercicios-disponibles')

            try:
                ejercicio = models.Ejercicio.objects.get(identificador=ejercicio_id)

                if request.method == 'POST' and 'archivoSubido' in request.FILES:
                    # Procesar el archivo subido
                    archivo_subido = request.FILES['archivoSubido']

                    # Crear directorio para almacenar la respuesta del ejercicio si no existe
                    directorio_ejercicio = os.path.join(settings.BASE_DIR, 'respuestasEjercicios', str(ejercicio.identificador))
                    if not os.path.exists(directorio_ejercicio):
                        os.makedirs(directorio_ejercicio)

                    # Crear directorio entornoAislado
                    directorio_aislado = os.path.join(settings.BASE_DIR, 'entornoAislado')
                    if not os.path.exists(directorio_aislado):
                        os.makedirs(directorio_aislado)

                    # Obtener datos del alumno
                    alumno = models.Alumno.objects.get(usuario=datoSesion['usuario'])

                    # Generar identificador único para la respuesta
                    identificador_respuesta = generarAleatorio.creadorIdentificador()

                    # Construir el nuevo nombre de archivo
                    extension_archivo = archivo_subido.name.split('.')[-1]
                    nombre_archivo = f"{identificador_respuesta}_{ejercicio.identificador}_{alumno.usuario}.{extension_archivo}"
                    ruta_archivo = os.path.join(directorio_ejercicio, nombre_archivo)

                    # Guardar archivo en el sistema de archivos
                    with open(ruta_archivo, 'wb+') as destination:
                        for chunk in archivo_subido.chunks():
                            destination.write(chunk)

                    # Copiar archivoSubido al directorio aislado
                    ruta_archivo_aislado = os.path.join(directorio_aislado, os.path.basename(nombre_archivo))
                    shutil.copy(ruta_archivo, ruta_archivo_aislado)

                    # Copiar archivoEntradas al directorio aislado
                    archivo_entradas = ejercicio.archivoEntradas
                    ruta_entradas_aislado = os.path.join(directorio_aislado, os.path.basename(archivo_entradas))
                    shutil.copy(archivo_entradas, ruta_entradas_aislado)

                    # Cambiar al directorio aislado y listar archivos usando comandos del sistema
                    try:
                        os.chdir(directorio_aislado)
                        archivos_en_aislado = os.listdir(directorio_aislado)

                        # Ejecutar el comando python iniciador.py archivoSubido archivo_entradas
                        comando_python = f"python iniciador.py {os.path.basename(ruta_archivo_aislado)} {os.path.basename(ruta_entradas_aislado)}"
                        resultado_comando = subprocess.run(comando_python, shell=True, check=True, capture_output=True, text=True)
                        salida_comando = resultado_comando.stdout

                        puntosObtenidos = extraer_puntos(salida_comando)

                    except subprocess.CalledProcessError as e:
                        return render(request, 'detalleEjercicioDisponible.html', {'ejercicio': ejercicio})

                    # Obtener la fecha actual de subida
                    fecha_subida = make_aware(datetime.now())

                    # Guardar la ruta relativa en la base de datos
                    nueva_respuesta = models.Respuesta.objects.create(
                        identificadorRespuesta=identificador_respuesta,
                        ejercicio=ejercicio,
                        estudiante=alumno,
                        puntos=puntosObtenidos,
                        archivoSubido=ruta_archivo,  # Ruta absoluta
                        fechaSubida=fecha_subida
                    )

                    # Eliminar los archivos copiados después de crear el registro en la base de datos
                    os.remove(ruta_archivo_aislado)
                    os.remove(ruta_entradas_aislado)

                    administradorBitacoras.registrarMensaje(f"El alumno {alumno.matricula} subió su respuesta al ejercicio {ejercicio_id}", 0)

                    mensaje = "Se ha subido correctamente tu respuesta."
                    return render(request, 'detalleEjercicioDisponible.html', {'ejercicio': ejercicio, 'mensaje': mensaje, 'archivos': archivos_en_aislado, 'salida_comando': salida_comando})

                return render(request, 'detalleEjercicioDisponible.html', {'ejercicio': ejercicio})

            except models.Ejercicio.DoesNotExist:
                administradorBitacoras.registrarMensaje(f"El ejercicio {ejercicio_id} no existe.", 1)
                return render(request, 'detalleEjercicioDisponible.html', {'mensaje': "El ejercicio no existe."})

            except models.Alumno.DoesNotExist:
                administradorBitacoras.registrarMensaje(f"El alumno con usuario {datoSesion['usuario']} no existe.", 1)
                return redirect('/login') #, {'errores': "El alumno no existe.", 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

        else:
            request.session['logueado'] = False
            request.session.flush()
            administradorBitacoras.registrarMensaje(f"Intento de acceso no autorizado a detalleEjercicioDisponible.", 1)
            return redirect('/login') #, {'errores': "Por favor inicie sesión correctamente.", 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

    else:
        request.session['logueado'] = False
        request.session.flush()
        administradorBitacoras.registrarMensaje(f"Intento de acceso no autorizado a detalleEjercicioDisponible.", 1)
        return redirect('/login') #, {'errores': "Por favor inicie sesión.", 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

def ejerciciosEntregados(request):
    """
    Vista para mostrar los ejercicios entregados por un alumno.

    Permite a un alumno ver todos los ejercicios que ha entregado.

    Parameters:
    - request (HttpRequest): Objeto que contiene los datos de la solicitud HTTP.

    Returns:
    - HttpResponse: Renderiza la plantilla 'ejerciciosEntregados.html' con las respuestas entregadas por el alumno.
    """
    if 'logueo' in request.session:
        datoSesion = request.session.get('logueo', {})
        if datoSesion['token'] == "Alumno":
            try:
                alumno = models.Alumno.objects.get(usuario=datoSesion['usuario'])

                # Obtener respuestas del alumno
                respuestas = models.Respuesta.objects.filter(estudiante=alumno)

                return render(request, 'ejerciciosEntregados.html', {'respuestas': respuestas})

            except models.Alumno.DoesNotExist:
                error = "La sesión no es de un Alumno."
                administradorBitacoras.registrarMensaje(f"Error en inicio de sesión en ejerciciosEntregados: {error}", 1)
                return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

        else:
            request.session['logueado'] = False
            request.session.flush()
            error = "Por favor inicie sesión correctamente."
            administradorBitacoras.registrarMensaje(f"Intento de acceso no autorizado a ejerciciosEntregados: {error}", 1)
            return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})

    else:
        request.session['logueado'] = False
        request.session.flush()
        error = "Por favor inicie sesión."
        administradorBitacoras.registrarMensaje(f"Intento de acceso no autorizado a ejerciciosEntregados: {error}", 0)
        return redirect('/login') #, {'errores': error, 'tu_clave_publica': settings.RECAPTCHA_PUBLIC_KEY})
